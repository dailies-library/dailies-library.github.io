// A website's first-page preview: its picture, title and description, read from the page's own preview tags.
// Read-only and careful: https only, public addresses only (never localhost, a home router or an office network), no login
// or cookies sent, a size limit, and a time limit, so a link can never make this look at anything private or hang.

export function publicHost(host) {
  const h = String(host || '').toLowerCase().replace(/^\[|\]$/g, '').replace(/\.+$/, '') // 'localhost.' is localhost
  if (!h || h.includes(':')) return false // IPv6 addresses are skipped
  if (!h.includes('.')) return false // single names like localhost or an office server
  if (/\.(local|localhost|internal|lan|home|corp|intranet|localdomain)$/.test(h)) return false
  const ip = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/)
  if (ip) {
    const [a, b] = [+ip[1], +ip[2]]
    if (a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return false
  }
  return true
}

const entities = s => String(s ?? '').replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|nbsp);/gi, (m, e) => {
  if (e[0] === '#') { const n = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : '' }
  return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' }[e.toLowerCase()]
})

// the head of the page, as far as we need it
async function readHead(res, max = 600000) {
  const reader = res.body && res.body.getReader ? res.body.getReader() : null
  if (!reader) return (await res.text()).slice(0, max)
  const dec = new TextDecoder('utf-8', { fatal: false })
  let html = '', n = 0
  while (n < max) {
    const { done, value } = await reader.read()
    if (done) break
    n += value.length
    html += dec.decode(value, { stream: true })
    if (/<\/head>/i.test(html) || /<body[\s>]/i.test(html)) break // the preview tags are all in the head
  }
  try { await reader.cancel() } catch { /* already closed */ }
  return html
}

export function siteMeta(html, base) {
  const metas = {}
  for (const m of html.matchAll(/<meta\s[^>]*>/gi)) {
    const tag = m[0]
    const attr = n => { const r = tag.match(new RegExp(`\\b${n}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i')); return r ? entities(r[1] ?? r[2] ?? r[3]) : '' }
    const key = (attr('property') || attr('name')).toLowerCase()
    if (key && !(key in metas)) metas[key] = attr('content').trim()
  }
  const abs = u => { try { return u ? new URL(u, base).href : '' } catch { return '' } }
  let icon = ''
  for (const m of html.matchAll(/<link\s[^>]*>/gi)) {
    const tag = m[0], rel = (tag.match(/\brel\s*=\s*["']?([^"'>]+)/i) || [])[1] || '', href = (tag.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i) || [])[1] || (tag.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i) || [])[2]
    if (/apple-touch-icon/i.test(rel) && href) { icon = abs(entities(href)); break }
  }
  const title = metas['og:title'] || metas['twitter:title'] || entities((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '').replace(/\s+/g, ' ').trim()
  return {
    title: title.slice(0, 300),
    desc: (metas['og:description'] || metas['twitter:description'] || metas['description'] || '').slice(0, 600),
    site: metas['og:site_name'] || '',
    image: abs(metas['og:image:secure_url'] || metas['og:image'] || metas['twitter:image'] || metas['twitter:image:src']),
    icon,
  }
}

// → { title, desc, site, image, icon } or null. Resolves within `ms` whatever the site does.
export async function sitePage(url, ms = 6000) {
  let u
  try { u = new URL(url) } catch { return null }
  if (u.protocol !== 'https:' || !publicHost(u.hostname)) return null
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), ms)
  try {
    const res = await fetch(u.href, { credentials: 'omit', redirect: 'follow', signal: ctl.signal, headers: { Accept: 'text/html,application/xhtml+xml' } })
    if (!res.ok || res.status === 202 || res.headers.get('x-amzn-waf-action')) return null // 202 / WAF header: a bot check, not the page
    const end = new URL(res.url || u.href)
    if (end.protocol !== 'https:' || !publicHost(end.hostname)) return null // it was sent somewhere private: ignore what came back
    const type = res.headers.get('content-type') || ''
    if (/^image\//i.test(type)) return { title: '', desc: '', site: '', image: end.href, icon: '' } // the link is a picture
    if (type && !/html|xml/i.test(type)) return null
    return siteMeta(await readHead(res), end.href)
  } catch { return null } finally { clearTimeout(timer) }
}
