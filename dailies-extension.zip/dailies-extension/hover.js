// Runs on the sites people save references from: Instagram, X, Pinterest, YouTube, and design sites like Behance and Dribbble.
// Moving the pointer over a post shows a small "Save" button on its picture or video, the way Cosmos does; one click sends that
// post (not the whole page) to Dailies. Nothing is read or sent until you click. Turn it off in the extension's popup.
(() => {
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id) } catch { return false } }
  if (typeof window.__dailiesHover === 'function' && window.__dailiesHover()) return // already running here
  window.__dailiesHover = alive
  // an older copy left behind by an extension update: take its button off the page
  for (const el of document.querySelectorAll('[data-dailies-hover]')) el.remove()
  const LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAAAAAAAAQCEeRdzAAABAGlDQ1BpY2MAAHicY2BgPMEABCwGDAy5eSVFQe5OChGRUQrsDxgYgRAMEpOLCxhwA6Cqb9cgai/r4lGHC3CmpBYnA+kPQKxSBLQcaKQIkC2SDmFrgNhJELYNiF1eUlACZAeA2EUhQc5AdgqQrZGOxE5CYicXFIHU9wDZNrk5pckIdzPwpOaFBgNpDiCWYShmCGJwZ3AC+R+iJH8RA4PFVwYG5gkIsaSZDAzbWxkYJG4hxFQWMDDwtzAwbDuPEEOESUFiUSJYiAWImdLSGBg+LWdg4I1kYBC+wMDAFQ0LCBxuUwC7zZ0hHwjTGXIYUoEingx5DMkMekCWEYMBgyGDGQCm1j8/adLZwQAABoNJREFUeJyVV9tyIzUQ7ZY0M7YTwiZ7CQsPfBCfxG9SxSOP3KqAIuw69owkzunusZ3dJcXKNaW5SN2nT99k/em774Wjq0htVd5L6cuyyC99kv1+Lz/KjTw8PMgPcm3Pv6aNrd8NR9lut/LN9E6ur6/kvryX7W4rX+ZHKSXLTqvklES0iyaVxFlVNtp0HEe5w7ppmqRIjKUBRE99sfsuc8dMVOrfM+YCQRmCem8OundpTQV4pRaVij0Ne0WgWKopHLPYXLQBWJLrLL0MXXd4P5QKc9UFLZpMbMWLBVorGYlvFJDXC9+ow9ZhA4Hyqni5AEFLHaodoIKBpLPknGULhQSw1UVKbn2CNTSocDN5qpoguMkBpMxCBhKAZAMBI2FTt8tWY22HMmwytipAztA50BqzHjBTxcIWzIlMuOAZ2WDOAAnCoKFrOWo2qQdspoqDWZ/8ggXdtNNuDVeoKeTrih21ZZkXrBvIjK9JK1vYNwDIkJMMiImRLgwgZBVXL486GM0HKGuNDLjVR+A7AlBTvwgOXDoQY1jtaviCpdjLR0jGgznKlCVYnwAGM0xOJiKZ8k492FMeIJQACKTh90jqwduhDnJAwMGDMmsSCQe4x9T8a9baL5sywkuwmldOA+aCy7NBFfcAuGC1gqmDbKQBQflDd7QB1hJ8kyMW0vfvMNOvx4o5V6O6Qig304oE/06lyDRUzBnXgPsiY5lA+QilBDMYE3ThohMMzZDnwB/kC7hulvJbmuzFzBhgNuC+5QAA2vZA/Ih0WQCgDYOMzQVc5QV5XOQWiXw1THI1qmzLTjLWJgComWmYweIkRwTMTBcya9Qt/6u/dAC/6NYEtsyA657bSpcw1bLsKQTKdUHkQsgtpBQAfIH02u528qosstls5HrcyQiACjYagxlFDakNxc19DuDmatlZrP3db4QFr/xcHIB2yx5bRCAzAcMlhyoWA5sjLJs28lreyYgK9gpWjsMI63dSoLjlwRRVHa0gHcGoVl3rHGGY7H1zAHtbV6T8nq88vVo/LUZBtGrHGZ4HpZPc539kQAn9Fs+cb8TTrAIEx6N6iT70TbgyWTrWvgIo9v64zt3n8qcMHs0pSi6sJgMpKuCd7lEyB3mLajJNWe6xnpWtMOaVMeKCOsBwX+vuyoM4sKbOQmWWdeZZjjLuaVz2uZxdgDGou2JXgRVR/qK9R3SrvMHrsXS5rkw7Nf9S8dorWsvG2kxA/Kmn9xwGVqsd2euJePPjKEw7u7HmgY/dm8gVmBjggjcJQQYgt43bW+S0REkOtCxHVsg0Cnb3RmaFKuJq3bS6BO/oolM3pHLrXq2ab2/bLBPevQaQsS1Ww62lriZHw+koWrWKV0z8FvOnA2Nn7GawStycLE8hp6yWUAkr1Qt0qwEC3iYAgFUvUXAGiC1E3JwlUs1q16wdu0nsD1YpwzXtrPPJ4J51GAP0PdftOuOUvj6iaYh8Be+NkLJl/PZmrFwO28crGHCNcirXPRStFq/UJ71ITWbBiCNIQc2+o0JY/nWlYpG7xHgFC6aXJ4R0kmOx8sGgtb2dFVvxubD2QwZWIKjcoBjmvGqP5ud79bglI7mphZgrrCHCo529nnCST+vjGdAnlDM92SM4RzZKuYbvJ/j+Hl1rgqU32i0jxoh274H1JEQDkMcWQ7JarFsnrh7Zl8rX9DbmklvNuQcLZYe028GZt6QbYjd4zuzTjPIupzz/cGiYW5KfiBgn1Q51TsVHLtB29tUFMPSvGSfYEWdeT7chu+V6CuGz9Z8alhnSrfwwEQceTMEEu6EYnPwRE5fDYmDLMxuUDkTOQmS/T+TQBaASsZBxomuVrC2iAQInrTg9c85PmGhr/VgrYTb6uvA8lCMVnfrnLV9HhnL2jQH1o5MBO9LyUBtRVoOJkz1+s54fy/n1+dT7f8Y5GJs9MICpeKtzVMQcfLnMJZhIwUALIGU99z8R/iTtnh8p/juMbN+Yp+5AGv8d8FwRCnPEVAsqluiepVsN/49Qf3bUECwWC0Vd8QY9xA81vmoOkmt0y5q9Oy7NFxT4QvEvp6+l1XvY5w1zBWMGG0eoFPtH51KW7kBnFgqyFTHhfweaFoZM9dWns8vHyfKM8phLW1/U+DsX79VjYQwgS5w9U4LNdAHbJz/xCMd2rp9tfw0WXJFVQmFKry6q0R0j6Nq5hjIOLQbqWekFE583VgnZgpF0RBaET3tUQjQjtaAVz4p/AQnNeoRzdrjuAAAAAElFTkSuQmCC'
  const abs = h => { try { return new URL(h, location.href).href } catch { return '' } }
  const rectOf = el => el.getBoundingClientRect()
  const big = (el, w = 120, h = 90) => { const r = rectOf(el); return r.width >= w && r.height >= h }
  const area = el => { const r = rectOf(el); return r.width * r.height }
  const biggest = (root, sel = 'img, video') => [...root.querySelectorAll(sel)].filter(e => big(e)).sort((a, b) => area(b) - area(a))[0] || null
  const srcOf = im => im ? (im.tagName === 'VIDEO' ? im.poster : im.currentSrc || im.src) || '' : ''
  // the picture or video under the pointer, even when the site lays a see-through layer over it
  const mediaAt = (x, y, w, h) => {
    const stack = document.elementsFromPoint(x, y)
    const hit = stack.find(e => (e.tagName === 'IMG' || e.tagName === 'VIDEO') && big(e, w, h))
    if (hit) return hit
    // some sites (Behance) switch the picture's pointer off, so it isn't "under" the pointer: look inside what is
    const inside = r => x >= r.left && x <= r.right && y >= r.top && y <= r.bottom
    for (const el of stack.slice(0, 8)) {
      const m = [...el.querySelectorAll('img, video')].find(e => big(e, w, h) && inside(rectOf(e)))
      if (m) return m
    }
    return null
  }

  // each site: the post under the pointer, the box(es) the button sits on, its corner (always top right, `inset` px further left where the site's own buttons sit), and what to save
  const SITES = [
    { name: 'x', test: /^(x|twitter)\.com$/, find(el) {
      const a = el.closest('article[data-testid="tweet"]')
      if (!a) return null
      const boxes = [...a.querySelectorAll('[data-testid="tweetPhoto"], [data-testid="videoPlayer"]')].filter(e => big(e, 80, 60))
      const link = a.querySelector('a[href*="/status/"] time')?.closest('a')?.getAttribute('href') || (/\/status\/\d+/.test(location.pathname) ? location.pathname : '')
      if (!boxes.length || !link) return null
      return { key: a, boxes, corner: 'right', url: abs(link), img: srcOf(boxes.map(b => b.querySelector('img')).find(Boolean)), video: boxes.some(b => b.matches('[data-testid="videoPlayer"]')) }
    } },
    { name: 'instagram', test: /^instagram\.com$/, find(el, x, y) {
      const tile = el.closest('a[href*="/p/"], a[href*="/reel/"]')
      if (tile && !tile.closest('article')) { // a profile, explore or saved grid
        const im = biggest(tile, 'img')
        return im ? { key: tile, boxes: [tile], corner: 'right', inset: 40, url: abs(tile.getAttribute('href')), img: srcOf(im) } : null
      }
      const art = el.closest('article')
      if (art) { // a post in the feed, or the post page
        const m = biggest(art)
        const link = art.querySelector('time')?.closest('a')?.getAttribute('href') || (/^\/(p|reels?)\/[\w-]+/.test(location.pathname) ? location.pathname : '')
        return m && link ? { key: art, boxes: [m], corner: 'right', url: abs(link), img: srcOf(biggest(art, 'img')), video: m.tagName === 'VIDEO' } : null
      }
      if (/^\/reels?\/[\w-]+/.test(location.pathname)) { // the reels player: the address follows the reel on screen
        const v = mediaAt(x, y, 200, 300)
        return v ? { key: v, boxes: [v], corner: 'right', url: location.origin + location.pathname.replace(/^\/reels\//, '/reel/'), video: true } : null
      }
      return null
    } },
    { name: 'pinterest', test: /(^|\.)pinterest\.[a-z.]+$/, find(el, x, y) {
      const g = el.closest('[data-grid-item], [data-test-id="pin"]')
      if (g) {
        const a = g.querySelector('a[href*="/pin/"]'), m = biggest(g), pic = g.querySelector('img')
        return a && m ? { key: g, boxes: [m], corner: 'right', inset: 92, url: abs(a.getAttribute('href')), img: srcOf(pic).replace(/\/(\d+x|236x|474x|564x)\//, '/736x/'), title: pic && pic.alt } : null
      }
      if (/^\/pin\/[\w-]+/.test(location.pathname)) { // a pin's own page
        const m = mediaAt(x, y, 240, 200)
        return m ? { key: m, boxes: [m], corner: 'right', url: location.origin + location.pathname, img: srcOf(m), title: m.alt } : null
      }
      return null
    } },
    { name: 'youtube', test: /^youtube\.com$/, find(el) {
      const c = el.closest('yt-lockup-view-model, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-playlist-video-renderer, ytd-reel-item-renderer, ytd-rich-item-renderer')
      if (c) {
        const a = c.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]'), box = biggest(c, 'yt-thumbnail-view-model, ytd-thumbnail, img, video')
        return a && box ? { key: c, boxes: [box], corner: 'right', inset: 52, url: abs(a.getAttribute('href')) } : null
      }
      const p = el.closest('#movie_player, ytd-reel-video-renderer, #shorts-player')
      if (p && /^\/(watch|shorts\/)/.test(location.pathname)) { const v = p.querySelector('video'); return { key: p, boxes: [v && big(v) ? v : p], corner: 'right', url: location.href, video: true } }
      return null
    } },
    { name: 'design', test: /(^|\.)(behance\.net|dribbble\.com|are\.na|tumblr\.com|savee\.(it|com)|cosmos\.so)$/, find(el, x, y) {
      const m = mediaAt(x, y, 240, 180)
      if (!m) return null
      // the project's own link: on the picture, or on a see-through layer over it (Dribbble, Behance)
      const a = m.closest('a[href]') || document.elementsFromPoint(x, y).map(e => e.closest('a[href]')).find(Boolean)
      const href = abs(a?.getAttribute('href') || '')
      const same = href && new URL(href).hostname === location.hostname
      return { key: m, boxes: [m], corner: 'right', url: same ? href : location.href, img: srcOf(m), title: m.alt || document.title, video: m.tagName === 'VIDEO' }
    } },
  ]
  const host = location.hostname.replace(/^(www|m)\./, '')
  const site = SITES.find(s => s.test.test(host))
  if (!site) return

  // what you've saved with this button, so it says "Saved" when you come back
  const keyOf = u => { try { const x = new URL(u); return x.hostname.replace(/^(www|m)\./, '') + x.pathname.replace(/\/$/, '') + (x.searchParams.get('v') ? '?v=' + x.searchParams.get('v') : '') } catch { return u } }
  let saved = new Set(), off = false
  chrome.storage.local.get(['hoverSaved', 'hoverOff']).then(s => { saved = new Set(s.hoverSaved || []); off = !!s.hoverOff })
  chrome.storage.onChanged.addListener(ch => {
    if (!chrome.runtime?.id) return
    if (ch.hoverOff) { off = !!ch.hoverOff.newValue; if (off) hide(true) }
    if (ch.hoverSaved) saved = new Set(ch.hoverSaved.newValue || [])
  })

  // the button lives in its own closed shadow root on top of the page, so the site's styles and clicks never touch it
  const hostEl = document.createElement('div')
  hostEl.style.cssText = 'position:fixed;inset:0 auto auto 0;width:0;height:0;z-index:2147483647'
  hostEl.dataset.dailiesHover = '1'
  const root = hostEl.attachShadow({ mode: 'closed' })
  root.innerHTML = `<style>
    button { position: fixed; display: none; align-items: center; gap: 8px; height: 36px; padding: 0 14px 0 7px; border-radius: 10px; cursor: pointer;
      border: 1px solid rgba(255,255,255,.18); background: rgba(12,12,12,.8); color: #fff; backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
      font: 600 13.5px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; letter-spacing: 0; box-shadow: 0 4px 16px rgba(0,0,0,.35);
      opacity: 0; transition: opacity .15s ease, background .15s ease, border-color .15s ease; white-space: nowrap; }
    button.on { display: inline-flex; }
    button.shown { opacity: 1; }
    button:hover { background: rgba(0,0,0,.92); }
    img { width: 22px; height: 22px; border-radius: 6px; display: block; }
    svg { width: 16px; height: 16px; display: none; }
    button[data-s="saved"] { border-color: rgba(73,201,141,.65); cursor: default; }
    button[data-s="saved"] img { display: none; }
    button[data-s="saved"] svg { display: block; margin-left: 4px; }
    button[data-s="saving"] { cursor: progress; }
    button[data-s="saving"] img { animation: breathe 1.1s ease-in-out infinite; }
    svg path { stroke-dasharray: 22; stroke-dashoffset: 0; }
    button.fresh svg path { animation: tick .45s cubic-bezier(.2,.8,.2,1) both; }
    button.fresh { animation: ring .9s ease-out; }
    @keyframes breathe { 50% { opacity: .5; } }
    @keyframes tick { from { stroke-dashoffset: 22; } }
    @keyframes ring { from { box-shadow: 0 0 0 0 rgba(73,201,141,.5), 0 4px 16px rgba(0,0,0,.35); } to { box-shadow: 0 0 0 12px rgba(73,201,141,0), 0 4px 16px rgba(0,0,0,.35); } }
    /* the scan (like Pinterest's): the post eases into a slightly smaller rounded card and a soft, blurred glow
       in blue, violet and peach drifts down over it, then it eases back. The glow lives in its own layer that lightens the page (screen). */
    .scan { position: fixed; display: none; pointer-events: none; overflow: hidden; border-radius: 16px; }
    .scan.run { display: block; }
    .glow { position: absolute; left: -15%; right: -15%; top: 0; height: 75%; opacity: 0; transform: translateY(-110%); filter: blur(26px);
      background: radial-gradient(38% 55% at 20% 50%, rgba(90,120,255,.85), transparent 70%), radial-gradient(36% 50% at 50% 42%, rgba(176,108,255,.8), transparent 70%),
        radial-gradient(40% 55% at 82% 56%, rgba(255,166,128,.8), transparent 70%), radial-gradient(60% 38% at 50% 50%, rgba(255,255,255,.4), transparent 72%); }
    .scan.in .glow { opacity: 1; transition: opacity .3s ease; animation: drift 1.6s cubic-bezier(.35,.12,.5,.95) infinite; }
    .scan.done .glow { opacity: 0; transition: opacity .4s ease; }
    @keyframes drift { to { transform: translateY(calc(var(--h, 400px) * 1.15)); } }
    @media (prefers-reduced-motion: reduce) { .scan { display: none !important; } button, button * { animation: none !important; } }
  </style><button type="button" aria-label="Save to Dailies"><img alt="" src="${LOGO}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.2 4.2L19 7" fill="none" stroke="#49c98d" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Save</span></button>`
  const btn = root.querySelector('button'), label = root.querySelector('span')
  for (const t of ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'touchstart', 'touchend']) hostEl.addEventListener(t, e => e.stopPropagation())
  ;(document.documentElement || document.body).appendChild(hostEl)
  // the glow gets a layer of its own, set to lighten what's under it (a blend inside the button's layer couldn't reach the page)
  const glowHost = document.createElement('div')
  glowHost.dataset.dailiesHover = '1'
  glowHost.style.cssText = 'position:fixed;inset:0 auto auto 0;width:0;height:0;z-index:2147483646;mix-blend-mode:screen;pointer-events:none'
  const groot = glowHost.attachShadow({ mode: 'closed' })
  groot.innerHTML = '<style>' + root.querySelector('style').textContent + '</style><div class="scan"><i class="glow"></i></div>'
  const scan = groot.querySelector('.scan')
  ;(document.documentElement || document.body).appendChild(glowHost)

  let cur = null, hideTimer = 0, lastX = 0, lastY = 0, raf = 0, scanning = null, dead = false
  function retire() { // the extension was updated: the new version adds a fresh button, this one steps aside
    if (dead) return
    dead = true
    hostEl.remove(); glowHost.remove()
  }
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches
  const wait = ms => new Promise(r => setTimeout(r, ms))
  // the post itself eases a little smaller into a rounded card while it's looked at, then back (its own styles are put back after)
  function squeeze(post, on) {
    if (calm) return
    for (const el of post.boxes) {
      if (on && !el.__dailies) {
        el.__dailies = [el.style.transform, el.style.transition, el.style.borderRadius, el.style.overflow]
        el.style.transition = 'transform .35s cubic-bezier(.2,.8,.2,1), border-radius .35s ease'
        el.style.transform = 'scale(.955)'; el.style.borderRadius = '16px'; el.style.overflow = 'hidden'
      } else if (!on && el.__dailies) {
        const [t, tr, br, ov] = el.__dailies
        el.style.transform = t; el.style.borderRadius = br
        setTimeout(() => { el.style.transition = tr; el.style.overflow = ov; delete el.__dailies }, 400)
      }
    }
  }
  function startScan(post) {
    scanning = { post, at: performance.now() }
    squeeze(post, true)
    scan.className = 'scan run'
    const follow = () => { if (!scanning || scanning.post !== post) return; place(); requestAnimationFrame(follow) } // stays on the card as it shrinks
    follow()
    requestAnimationFrame(() => requestAnimationFrame(() => scan.classList.add('in')))
  }
  async function endScan(ok) { // at least one full pass of the glow, then it fades and the post eases back
    if (!scanning) return
    const left = 1600 - (performance.now() - scanning.at)
    if (ok && !calm && left > 0) await wait(left)
    scan.classList.add('done')
    squeeze(scanning.post, false)
    const post = scanning.post
    setTimeout(() => { if (scanning && scanning.post === post) { scan.className = 'scan'; scanning = null } }, 450)
    if (ok && !calm) await wait(250)
  }
  function setState(s) {
    btn.dataset.s = s
    label.textContent = s === 'saved' ? 'Saved' : s === 'saving' ? 'Saving…' : s === 'error' ? 'Try again' : s === 'reload' ? 'Reload the page' : 'Save'
  }
  function place() {
    if (!cur) return
    if (!cur.key.isConnected) return hide(true)
    const rs = cur.boxes.filter(b => b.isConnected).map(rectOf).filter(r => r.width && r.height)
    if (!rs.length) return hide(true)
    const r = { top: Math.min(...rs.map(x => x.top)), left: Math.min(...rs.map(x => x.left)), right: Math.max(...rs.map(x => x.right)), bottom: Math.max(...rs.map(x => x.bottom)) }
    if (r.bottom < 60 || r.top > innerHeight - 50 || r.right - r.left < 90) return hide(true)
    const w = btn.offsetWidth || 90
    const top = Math.max(r.top + 10, 10) // top right on every site; `inset` keeps it left of the site's own buttons in that corner
    const left = cur.corner === 'left' ? r.left + 10 : r.right - 10 - (cur.inset || 0) - w
    btn.style.top = Math.round(top) + 'px'
    btn.style.left = Math.round(Math.max(6, Math.min(innerWidth - w - 6, left))) + 'px'
    if (scanning && scanning.post === cur) {
      Object.assign(scan.style, { top: r.top + 'px', left: r.left + 'px', width: r.right - r.left + 'px', height: r.bottom - r.top + 'px' })
      scan.style.setProperty('--h', Math.round(r.bottom - r.top) + 'px')
    }
  }
  function show(post) {
    clearTimeout(hideTimer)
    if (scanning && cur && cur.key !== post.key) return // finish this one first
    if (!cur || cur.key !== post.key) {
      cur = post
      setState(saved.has(keyOf(post.url)) ? 'saved' : 'idle')
    } else { cur.boxes = post.boxes }
    btn.classList.add('on')
    place()
    requestAnimationFrame(() => btn.classList.add('shown'))
  }
  function hide(now) {
    clearTimeout(hideTimer)
    const go = () => { if (btn.dataset.s === 'saving') return; cur = null; btn.classList.remove('shown', 'on') }
    if (now) go(); else hideTimer = setTimeout(go, 220)
  }
  function look() {
    raf = 0
    if (dead) return
    if (!alive()) return retire()
    if (off) return
    const stack = document.elementsFromPoint(lastX, lastY)
    if (!stack.length || stack[0] === hostEl) { if (cur) clearTimeout(hideTimer); return } // on the button itself
    // the top element first, then what's beneath it: sites lay previews and see-through layers over posts (YouTube plays one on hover)
    let post = null
    for (const el of stack.slice(0, 16)) {
      try { post = site.find(el, lastX, lastY) } catch { post = null }
      if (post && post.url) break
    }
    if (post && post.url) show(post); else if (cur) hide()
  }
  addEventListener('pointermove', e => {
    if (e.pointerType === 'touch') return
    lastX = e.clientX; lastY = e.clientY
    if (!raf) raf = requestAnimationFrame(look)
  }, { passive: true, capture: true })
  addEventListener('scroll', () => { if (cur) requestAnimationFrame(() => { place(); if (!raf) raf = requestAnimationFrame(look) }) }, { passive: true, capture: true })
  addEventListener('resize', () => cur && place(), { passive: true })
  document.addEventListener('pointerleave', () => hide(), { passive: true })

  btn.addEventListener('click', async e => {
    e.preventDefault(); e.stopPropagation()
    const post = cur
    if (!post || btn.dataset.s === 'saving' || btn.dataset.s === 'saved') return
    setState('saving')
    startScan(post)
    try {
      const res = await chrome.runtime.sendMessage({ type: 'save-post', post: { url: post.url, img: post.img || '', title: post.title || '', video: !!post.video } })
      if (res && res.ok) {
        const k = keyOf(post.url)
        saved.add(k)
        chrome.storage.local.set({ hoverSaved: [...saved].slice(-3000) })
        await endScan(true)
        if (cur !== post) return
        setState('saved')
        btn.classList.add('fresh') // the tick draws itself and a soft green ring spreads once
        setTimeout(() => btn.classList.remove('fresh'), 1000)
      } else { endScan(false); if (cur === post) setState('error') }
    } catch {
      endScan(false)
      if (!alive()) { retire(); return } // the extension was updated since this page opened: the new button takes over
      if (cur === post) setState('error')
    }
    place()
  })
})()
