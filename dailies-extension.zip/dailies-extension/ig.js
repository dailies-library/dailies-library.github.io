// Runs on instagram.com. On one of your saved collections it reads the post and reel links off the grid, the same
// links you'd copy by hand, and hands them to the extension, which files them in Dailies.
// "Import" from the popup scrolls the whole collection; just opening a collection you follow picks up what's on screen.
(() => {
  if (window.__dailiesIg) return
  window.__dailiesIg = true

  const onSaved = () => /^\/[\w.]+\/saved(\/|$)/.test(location.pathname)
  const sleep = ms => new Promise(r => setTimeout(r, ms))

  // every post/reel tile currently in the grid, in page order (newest save first)
  function tiles() {
    const out = []
    for (const a of document.querySelectorAll('main a[href*="/p/"], main a[href*="/reel/"]')) {
      const m = a.getAttribute('href').match(/\/(p|reel)\/([\w-]+)/)
      if (!m) continue
      const img = a.querySelector('img')
      const label = [...a.querySelectorAll('svg[aria-label]')].map(s => s.getAttribute('aria-label')).join(' ')
      const reel = m[1] === 'reel' || /reel|clip|video/i.test(label)
      const alt = (img && img.getAttribute('alt')) || ''
      out.push({
        code: m[2], reel, carousel: /carousel/i.test(label),
        img: img && (img.currentSrc || img.src) || '',
        author: (alt.match(/\bby ([^\s,]+(?: [^\s,]+)?) (?:on|in|tagging)\b/i) || [])[1] || '',
      })
    }
    return out
  }

  let running = false
  async function scan(full, wait) {
    if (running || !onSaved()) return
    running = true
    const seen = new Set()
    let quiet = 0, blocked = false
    try {
      // a tab the extension opened in the background: Instagram fills in the grid a little after the page loads
      for (let t = 0; wait && t < 15 && !tiles().length; t++) await sleep(1000)
      for (let round = 0; round < (full ? 400 : 1); round++) {
        const fresh = tiles().filter(t => !seen.has(t.code))
        fresh.forEach(t => seen.add(t.code))
        if (fresh.length) {
          quiet = 0
          await chrome.runtime.sendMessage({ type: 'ig-links', url: location.href, items: fresh, total: seen.size, full })
        } else quiet++
        if (!full || quiet >= 4 || seen.size >= 3000) break // 3000 saves in one go is plenty; run Import again for more
        if (/try again later|please wait a few minutes|we restrict certain activity/i.test(document.body.innerText.slice(0, 4000))) { blocked = true; break } // Instagram is asking us to slow down: stop at once
        window.scrollTo(0, document.documentElement.scrollHeight) // load the next rows, like scrolling down yourself
        await sleep(1500 + Math.random() * 1700) // never at a steady, robotic pace
        if (round % 25 === 24) await sleep(8000 + Math.random() * 6000) // and a breather now and then, like someone looking at what they've found
      }
    } finally {
      running = false
      chrome.runtime.sendMessage({ type: 'ig-links', url: location.href, items: [], total: seen.size, done: true, full, blocked }).catch(() => {})
    }
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg && msg.type === 'ig-scan') { scan(!!msg.full, !!msg.wait); reply({ ok: onSaved() }) }
  })

  // Instagram changes pages without reloading: look again whenever the address changes to a saved collection
  let last = ''
  setInterval(() => {
    if (location.href === last) return
    last = location.href
    if (onSaved()) setTimeout(() => chrome.runtime.sendMessage({ type: 'ig-visit', url: location.href }).catch(() => {}), 2500)
  }, 1000)
})()
