import { publicHost } from './site-preview.js'

// Your Dailies library on Claude.
export const DAILIES = 'https://dailies-library.github.io/' // the Dailies website (on GitHub Pages since 25 Oct)
// Dailies itself (the site, or its code on GitHub): nothing to save there, the popup just says you're on Dailies (Rohit, 28 Oct)
export const isDailiesPage = u => { try { const x = new URL(u); return x.origin + '/' === DAILIES || (x.hostname === 'github.com' && /^\/dailies-library(\/|$)/i.test(x.pathname)) } catch { return false } }
export const DAILIES_SITES = [DAILIES] // the website only (the staging copy, claude.ai and the old Netlify address are no longer trusted)

// Dailies keeps a picture (the thumbnail) for every reference, not videos, GIFs or preview frames: no downloads of those. Set true to bring them back.
export const VIDEO_PREVIEWS = true
// Rohit, 25 Oct: a video of 5 MB or less is kept whole (it plays on hover and on phones); a bigger one keeps only a sheet of
// 40 frames (~200 KB) to scrub through. The same limit applies to GIFs.
export const VIDEO_KEEP = 5e6
export const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8)

async function toBase64Url(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer())
  let s = ''
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000))
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

// Any picture becomes a JPEG at most 1280px on its long side, which is what Dailies stores.
export async function toThumb(blob, max = 1280, quality = 0.85) {
  const bmp = await createImageBitmap(blob)
  const scale = Math.min(1, max / Math.max(bmp.width, bmp.height))
  const canvas = new OffscreenCanvas(Math.max(1, Math.round(bmp.width * scale)), Math.max(1, Math.round(bmp.height * scale)))
  const g = canvas.getContext('2d')
  g.fillStyle = '#000'
  g.fillRect(0, 0, canvas.width, canvas.height)
  g.drawImage(bmp, 0, 0, canvas.width, canvas.height)
  return toBase64Url(await canvas.convertToBlob({ type: 'image/jpeg', quality }))
}

export async function fetchThumb(url, max = 1280, quality = 0.85) {
  if (!url || !/^(https?|data):/.test(url)) return null
  if (/^https?:/.test(url)) { try { if (!publicHost(new URL(url).hostname)) return null } catch { return null } } // never a home or office network address a page pointed at
  try {
    const res = await fetch(url, { credentials: 'omit', signal: AbortSignal.timeout(8000) })
    if (!res.ok) return null
    return await toThumb(await res.blob(), max, quality)
  } catch {
    return null
  }
}

// Hosts the extension downloads videos, GIFs and YouTube frames from. Chrome can hold these back
// (e.g. after an update adds them), and a download without access fails with a CORS error, so
// check first and skip quietly; the popup offers "Allow video saving" to grant them.
export const MEDIA_ORIGINS = ['https://v1.pinimg.com/*', 'https://video.twimg.com/*', 'https://i.pinimg.com/*', 'https://www.youtube.com/*']
export async function canFetch(...origins) {
  try { return await chrome.permissions.contains({ origins }) } catch { return true } // outside Chrome (tests)
}

// Pinterest's public widget API says whether a pin is a picture or a video, and where the video's MP4 is.
// Dailies keeps a copy of short videos and GIFs (up to ~19 MB) so they can play inside it.
export async function pinMedia(pinId) {
  try {
    const res = await fetch(`https://widgets.pinterest.com/v3/pidgets/pins/info/?pin_ids=${pinId}`, { credentials: 'omit' })
    const pin = res.ok && (await res.json())?.data?.[0]
    return pin ? await mediaOfPin(pin) : null
  } catch {
    return null
  }
}
// the same pin, with the pictures of its other pages (if it is a story pin)
// the picture's file name is the same for a pin whatever id it is shown under (coded when signed out, a number when signed in)
export const picKeyOf = url => (String(url || '').match(/\/([0-9a-f]{32})\.\w+$/) || [])[1] || undefined
export async function pinFull(pinId) {
  try {
    const res = await fetch(`https://widgets.pinterest.com/v3/pidgets/pins/info/?pin_ids=${pinId}`, { credentials: 'omit' })
    const pin = res.ok && (await res.json())?.data?.[0]
    const im = (pin && pin.images) || {}
    return pin ? { media: await mediaOfPin(pin), slideUrls: pinSlideUrls(pin), pk: picKeyOf((im.orig || im['736x'] || im['564x'] || im['474x'] || im['237x'] || {}).url) } : null
  } catch {
    return null
  }
}

// the same check on a pin we already have (a board's pin list carries its videos)
export async function mediaOfPin(pin) {
  try {
    const mp4s = []
    const walk = o => {
      if (Array.isArray(o)) return o.forEach(walk)
      if (!o || typeof o !== 'object') return
      for (const [k, v] of Object.entries(o)) {
        if (k === 'video_list' && v && typeof v === 'object') Object.values(v).forEach(x => x && /\.mp4(\?|$)/.test(x.url || '') && mp4s.push(x))
        else walk(v)
      }
    }
    walk(pin)
    mp4s.sort((a, b) => (b.width || 0) - (a.width || 0)) // biggest first: the first that fits the limit is kept
    const v = mp4s.find(x => x.width <= 1280 || x.height <= 1280) || mp4s[0]
    if (!v) {
      // animated pins: the original upload of a GIF pin is kept as a .gif next to the resized JPEGs
      const shown = Object.values(pin.images || {}).map(x => x.url).find(Boolean) || ''
      const orig = shown.replace(/\/\d+x\//, '/originals/').replace(/\.\w+$/, '.gif')
      const g = orig !== shown && (await canFetch('https://i.pinimg.com/*')) && await fetch(orig, { credentials: 'omit' }).catch(() => null)
      if (g && g.ok) {
        // the type is in the headers: without GIF previews there is no need to download the whole (often several MB) file
        if (!VIDEO_PREVIEWS) { const gif = /image\/gif/i.test(g.headers.get('content-type') || ''); try { g.body && g.body.cancel() } catch { /* already done */ } if (gif) return { media: 'gif' } }
        else {
          const blob = await g.blob()
          if (blob.type === 'image/gif') return { media: 'gif', ...(blob.size <= VIDEO_KEEP && { gif: await toBase64Url(blob) }) }
        }
      }
      return { media: 'image' }
    }
    const out = { media: 'video', vw: v.width || null, vh: v.height || null, dur: v.duration ? Math.round(v.duration / 100) / 10 : null }
    if (!VIDEO_PREVIEWS || !(await canFetch('https://v1.pinimg.com/*'))) return out // it is a video (the label says so); the file itself is not kept
    return await keepOrFrames(out, mp4s.filter(x => x === v || (x.width || 0) < (v.width || 0)).map(x => x.url))
  } catch {
    return null
  }
}

// Instagram reels: the post's page (the same one we read for its caption) lists the MP4 under "video_versions".
// The hidden offscreen page turns it into a sheet of 40 frames, like YouTube's below. Photos give { scrub: 'none' }.
export function igVideoUrl(html) {
  const i = html.indexOf('"video_versions":[')
  if (i < 0) return null
  let k = html.indexOf('[', i), depth = 0, j = k
  for (; j < html.length; j++) { const ch = html[j]; if (ch === '[') depth++; else if (ch === ']' && !--depth) break; else if (ch === '"') { j++; while (j < html.length && html[j] !== '"') { if (html[j] === '\\') j++; j++ } } }
  try {
    const list = JSON.parse(html.slice(k, j + 1)).filter(x => x && x.url)
    const small = list.filter(x => x.width).sort((a, b) => a.width - b.width).find(x => x.width >= 480)
    return (small || list[0] || {}).url || null
  } catch { return null }
}
export async function videoFrames(url, keep = false) {
  if (!VIDEO_PREVIEWS) return null
  try {
    if (!(await chrome.offscreen.hasDocument())) await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['BLOBS'], justification: 'Read a saved video to make its preview frames' })
    // keep: when the file is VIDEO_KEEP or smaller, the offscreen page hands the whole video back too (it has it anyway)
    const out = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'video-frames', url, keep: keep ? VIDEO_KEEP : 0 })
    return out && out.scrub ? out : null
  } catch { return null }
}
// X and Pinterest videos: urls go from the best version to the smallest. The first one of VIDEO_KEEP or less is kept whole;
// if none fits, the smallest one is read for a sheet of frames instead (it's read, not kept).
async function keepOrFrames(out, urls) {
  for (const url of urls) {
    const head = await fetch(url, { method: 'HEAD', credentials: 'omit' }).catch(() => null)
    const size = head && head.ok ? +head.headers.get('content-length') : 0
    if (size && size > VIDEO_KEEP) continue
    const file = await fetch(url, { credentials: 'omit' }).catch(() => null)
    if (!file || !file.ok) continue
    const blob = await file.blob()
    if (blob.size > VIDEO_KEEP) continue
    out.vid = await toBase64Url(blob)
    return out
  }
  const frames = urls.length ? await videoFrames(urls[0]) : null // the best version (urls go best → smallest), so the frames are sharp
  return frames ? { ...out, ...frames } : out
}

// YouTube's hover-preview frames ("storyboards") come as sheets of small stills, about one per second.
// We pick up to 48 evenly spaced frames and lay them out on one JPEG, 8 across, so Dailies can flip
// through them as the mouse moves over a card. Returns { scrub: base64 JPEG, sn, sc, sw, sh } or { scrub: 'none' }.
export async function youtubeScrub(id) {
  if (!VIDEO_PREVIEWS) return { scrub: 'none' } // no preview frames: marked as looked at so it is not asked again
  try {
    if (!(await canFetch('https://www.youtube.com/*'))) return null // ask again once access is allowed
    const res = await fetch(`https://www.youtube.com/watch?v=${id}`, { credentials: 'omit' })
    const spec = res.ok && ((await res.text()).match(/"playerStoryboardSpecRenderer":\{"spec":"([^"]+)"/) || [])[1]
    if (!spec) return { scrub: 'none' }
    const [base, ...levels] = spec.replace(/\\u0026/g, '&').split('|')
    const L = levels.length - 1 // the biggest frames
    const [w, h, count, cols, rows, , name, sigh] = levels[L].split('#')
    const fw = +w, fh = +h, total = +count, per = cols * rows
    if (!fw || !fh || !total) return { scrub: 'none' }
    const n = Math.min(48, total), across = Math.min(8, n)
    const pick = Array.from({ length: n }, (_, k) => n === 1 ? 0 : Math.round(k * (total - 1) / (n - 1)))
    const sheets = {}
    const sheet = i => sheets[i] ||= fetch(base.replace('$L', L).replace('$N', name.replace('$M', i)) + '&sigh=' + sigh, { credentials: 'omit' })
      .then(r => r.ok ? r.blob() : Promise.reject(new Error('sheet ' + r.status))).then(b => createImageBitmap(b))
    const canvas = new OffscreenCanvas(across * fw, Math.ceil(n / across) * fh)
    const g = canvas.getContext('2d')
    for (const [k, f] of pick.entries()) {
      const bmp = await sheet(Math.floor(f / per))
      const j = f % per
      g.drawImage(bmp, (j % cols) * fw, Math.floor(j / cols) * fh, fw, fh, (k % across) * fw, Math.floor(k / across) * fh, fw, fh)
    }
    return { scrub: await toBase64Url(await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.8 })), sn: n, sc: across, sw: fw, sh: fh }
  } catch {
    return null
  }
}

export async function screenshotThumb(windowId) {
  try {
    const raw = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 88 })
    return await toThumb(await (await fetch(raw)).blob())
  } catch {
    return null
  }
}

// Runs inside the page you're saving: its preview tags, the biggest pictures on screen, and any selected text.
export function collectPage() {
  const meta = n => document.querySelector(`meta[property="${n}"], meta[name="${n}"]`)?.content || ''
  const abs = u => { try { return u ? new URL(u, location.href).href : '' } catch { return '' } }
  const lastSegment = u => { try { const x = new URL(u); return x.pathname.replace(/\/$/, '').split('/').pop() + (x.searchParams.get('v') || '') } catch { return '' } }
  let og = abs(meta('og:image') || meta('twitter:image'))
  let title = meta('og:title') || document.title
  let desc = meta('og:description') || meta('description')
  // Instagram, X and YouTube keep the previous page's tags after in-app navigation: only trust tags that describe this page.
  const ogUrl = meta('og:url')
  if (ogUrl && lastSegment(ogUrl) !== lastSegment(location.href)) { og = ''; title = document.title; desc = '' }
  const vw = innerWidth, vh = innerHeight
  const visible = el => {
    const r = el.getBoundingClientRect()
    return Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0))
  }
  const images = [
    ...[...document.images].map(img => ({ src: img.currentSrc || img.src, area: visible(img), w: img.naturalWidth })),
    ...[...document.querySelectorAll('video[poster]')].map(v => ({ src: abs(v.poster), area: visible(v), w: 999 })),
  ].filter(i => i.area > 15000 && i.w >= 200 && /^https?:/.test(i.src)).sort((a, b) => b.area - a.area).map(i => i.src)
  return {
    url: location.href,
    title, desc, og,
    images: [...new Set(images)].filter(s => s !== og).slice(0, 4),
    selection: String(getSelection() || '').trim().slice(0, 1000),
    ogUrl,
  }
}

// Instagram's tags read 'Name on Instagram: "caption"' — split that into creator and caption.
export function describe(page, source) {
  let title = (page.title || '').trim()
  let author = ''
  let caption = page.desc || ''
  if (source === 'instagram') {
    const user = (String(page.ogUrl || '').match(/instagram\.com\/([\w.]+)\/(?:p|reel|tv)\//) || [])[1] || (caption.match(/-\s*([\w.]+)\s+on\s+[A-Z][a-z]+ \d/) || [])[1]
    if (user) author = '@' + user
    const quoted = (title.match(/on Instagram:\s*["“]([\s\S]*?)["”]?\s*$/) || [])[1]
    if (quoted) caption = quoted
    title = (caption || title).split('\n')[0].slice(0, 200)
    if (/^Instagram$/i.test(title)) title = ''
  } else if (source === 'youtube') {
    title = title.replace(/\s*-\s*YouTube$/, '')
  }
  return { title: title.slice(0, 300), author, caption: caption.slice(0, 2000) }
}

// X doesn't put preview tags in the page when you're logged in, so posts are looked up on
// FixTweet (api.fxtwitter.com), a public service that returns a post's text, author and media.
// ---- carousels: the pictures after the first one. Dailies keeps them (smaller, ~1080px) so you can slide through them in Dailies.
const MAX_SLIDES = 9 // after the cover
export async function fetchMore(urls) {
  const list = [...new Set((urls || []).filter(Boolean))].slice(0, MAX_SLIDES), out = new Array(list.length)
  let next = 0
  await Promise.all([0, 1, 2].map(async () => { while (next < list.length) { const i = next++; out[i] = await fetchThumb(list[i], 1080, 0.8) } }))
  return out.filter(Boolean)
}
// an X post with several pictures: all of them, in order (FixTweet lists them)
export async function tweetSlides(url) {
  const id = (String(url).match(/\/status(?:es)?\/(\d+)/) || [])[1]
  if (!id) return []
  try {
    const res = await fetch(`https://api.fxtwitter.com/status/${id}`, { credentials: 'omit' })
    const t = res.ok && (await res.json()).tweet
    const photos = ((t && t.media && t.media.all) || []).filter(m => m.type === 'photo' && m.url)
    return photos.length > 1 ? photos.slice(1).map(m => m.url) : []
  } catch { return [] }
}
// a Pinterest story / multi-page pin: one picture per page
export function pinSlideUrls(pin) {
  const pages = (pin && pin.story_pin_data && pin.story_pin_data.pages) || []
  const urls = []
  for (const pg of pages) {
    const found = []
    const walk = o => {
      if (!o || typeof o !== 'object') return
      if (Array.isArray(o)) return o.forEach(walk)
      for (const [k, v] of Object.entries(o)) {
        if (k === 'image' && v && v.images) { const im = v.images.orig || v.images['1200x'] || v.images['736x'] || Object.values(v.images)[0]; if (im && im.url) found.push(im.url) }
        else if (k !== 'video') walk(v)
      }
    }
    walk(pg)
    if (found[0]) urls.push(found[0])
  }
  return urls.length > 1 ? urls.slice(1) : []
}
// an Instagram post with several pictures (Instagram's own web call for a post; one request, paced by the caller)
const IG_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
export const igMediaId = code => { try { let n = 0n; for (const c of String(code)) { const i = IG_ALPHABET.indexOf(c); if (i < 0) return null; n = n * 64n + BigInt(i) } return n.toString() } catch { return null } }
export function igSlideUrlsOf(json) {
  const item = json && json.items && json.items[0]
  const list = (item && item.carousel_media) || []
  const urls = list.map(m => { const c = m.image_versions2 && m.image_versions2.candidates; return c && c[0] && c[0].url }).filter(Boolean)
  return urls.length > 1 ? urls.slice(1) : []
}
// everything about one Instagram post from the call Instagram's own web page makes (needs your Instagram login): the cover,
// the caption, who posted it, the carousel's other pictures, a reel's video. Instagram no longer puts preview tags in its pages.
export function igPostOf(json) {
  const item = json && json.items && json.items[0]
  if (!item) return null
  const cands = m => (m && m.image_versions2 && m.image_versions2.candidates) || []
  const video = item.video_versions && item.video_versions[0] && item.video_versions[0].url
  return { cover: cands(item)[0] && cands(item)[0].url || null, caption: (item.caption && item.caption.text) || '', user: (item.user && item.user.username) || '', slides: igSlideUrlsOf(json), video: video || null }
}
export async function igPostInfo(code) {
  const id = igMediaId(code)
  if (!id) return { ok: false, stop: false }
  try {
    const res = await fetch(`https://www.instagram.com/api/v1/media/${id}/info/`, { credentials: 'include', headers: { 'X-IG-App-ID': '936619743392459', 'X-Requested-With': 'XMLHttpRequest' } })
    if (res.status === 429 || /challenge/.test(res.url || '')) return { ok: false, stop: true }
    if (!res.ok) return { ok: false, stop: false }
    const post = igPostOf(await res.json())
    return post ? { ok: true, stop: false, ...post } : { ok: false, stop: false }
  } catch { return { ok: false, stop: false } }
}
export async function igSlideUrls(code) {
  const id = igMediaId(code)
  if (!id) return { urls: [], stop: false }
  try {
    const res = await fetch(`https://www.instagram.com/api/v1/media/${id}/info/`, { credentials: 'include', headers: { 'X-IG-App-ID': '936619743392459', 'X-Requested-With': 'XMLHttpRequest' } })
    if (res.status === 429 || /challenge/.test(res.url || '')) return { urls: [], stop: true }
    if (!res.ok) return { urls: [], stop: false }
    return { urls: igSlideUrlsOf(await res.json()), stop: false }
  } catch { return { urls: [], stop: false } }
}
export async function tweetInfo(url) {
  const id = (String(url).match(/\/status(?:es)?\/(\d+)/) || [])[1]
  if (!id) return null
  try {
    const res = await fetch(`https://api.fxtwitter.com/status/${id}`, { credentials: 'omit' })
    if (!res.ok) return null
    const t = (await res.json()).tweet
    if (!t) return null
    const media = (t.media && t.media.all) || []
    const first = media[0] || (t.quote && t.quote.media && t.quote.media.all && t.quote.media.all[0])
    const text = (t.text || '').trim()
    return {
      title: text.split('\n')[0].slice(0, 200),
      caption: text,
      author: t.author ? `${t.author.name} (@${t.author.screen_name})` : '',
      thumb: first ? (first.type === 'photo' ? first.url : first.thumbnail_url) : null,
      video: media.some(m => m.type === 'video' || m.type === 'gif'),
    }
  } catch {
    return null
  }
}

// X videos are plain MP4s on video.twimg.com in a few sizes. Dailies keeps a copy of the best one
// up to 720p-ish that fits in ~19 MB, so it can play inside Dailies. X "GIFs" are MP4s too.
export async function tweetVideo(url) {
  const id = (String(url).match(/\/status(?:es)?\/(\d+)/) || [])[1]
  if (!id) return null
  try {
    const res = await fetch(`https://api.fxtwitter.com/status/${id}`, { credentials: 'omit' })
    const t = res.ok && (await res.json()).tweet
    if (!t) return null
    const all = [...((t.media && t.media.all) || []), ...((t.quote && t.quote.media && t.quote.media.all) || [])]
    const m = all.find(x => x.type === 'video' || x.type === 'gif')
    if (!m) return { media: 'image' }
    const out = { media: m.type === 'gif' ? 'gif' : 'video', vw: m.width || null, vh: m.height || null, dur: m.duration ? Math.round(m.duration * 10) / 10 : null }
    if (!VIDEO_PREVIEWS || !(await canFetch('https://video.twimg.com/*'))) return out // it is a video (the label says so); the file itself is not kept
    const mp4s = (m.formats || m.variants || []).filter(f => f.container === 'mp4' || /\.mp4(\?|$)/.test(f.url || ''))
      .filter(f => (f.bitrate || 0) <= 2.6e6).sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))
    if (!mp4s.length && m.url && /\.mp4(\?|$)/.test(m.url)) mp4s.push({ url: m.url })
    return await keepOrFrames(out, mp4s.map(f => f.url))
  } catch {
    return null
  }
}

// YouTube keeps the previous video's tags (or just "YouTube") as you click around, so ask its oEmbed endpoint.
export async function youtubeInfo(url) {
  try {
    const res = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`, { credentials: 'omit' })
    if (!res.ok) return null
    const o = await res.json()
    return { title: (o.title || '').slice(0, 300), author: o.author_name || '', caption: '' }
  } catch {
    return null
  }
}

// The best picture we can get for a page without your help: its preview image, a YouTube still, or the biggest one on screen.
// Instagram's preview image (og:image) has a play button baked into it; /media/?size=l redirects to the clean cover.
export function instagramCover(url) {
  const m = String(url || '').match(/instagram\.com\/(?:[\w.]+\/)?(?:reels?|p|tv)\/([\w-]+)/)
  return m ? `https://www.instagram.com/p/${m[1]}/media/?size=l` : null
}

// a YouTube Short has a vertical thumbnail (oar2 is 1080×1920); the usual ones are wide with bars on both sides
export const ytShortThumbs = id => [`https://i.ytimg.com/vi/${id}/oar2.jpg`, `https://i.ytimg.com/vi/${id}/oardefault.jpg`]
export async function bestThumb(page, ytId, extra = []) {
  const short = ytId && /\/shorts\//.test(page.url || '')
  const candidates = [...(short ? ytShortThumbs(ytId) : []), ...extra, instagramCover(page.url), ytId && `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg`, ytId && `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`, page.og, ...(page.images || [])].filter(Boolean)
  // all at once, best first: the answer is as quick as the best picture that exists, not the sum of every try
  const tries = candidates.map(src => src ? fetchThumb(src).then(t => t ? { img: t, src } : null) : Promise.resolve(null))
  for (const t of tries) { const r = await t; if (r) return r }
  return null
}


// ---- Pinterest boards, read the way pinterest.com's own pages read them (public boards) ----
async function pinResource(name, path, options, handler) {
  const data = encodeURIComponent(JSON.stringify({ options, context: {} }))
  const res = await fetch(`https://www.pinterest.com/resource/${name}/get/?source_url=${encodeURIComponent(path)}&data=${data}`, {
    // with your Pinterest login when you have one: signed out, Pinterest shows only a board's newest 25 to 50 pins
    credentials: 'include', headers: { Accept: 'application/json', 'X-Pinterest-PWS-Handler': handler },
  })
  const body = await res.json().catch(() => null)
  const rr = body && body.resource_response
  if (!res.ok || !rr || rr.error) {
    const why = rr && rr.error && rr.error.message
    throw new Error(res.status === 404 || /not found/i.test(why || '') ? 'not-found' : why || `Pinterest answered ${res.status}`)
  }
  return { data: rr.data, bookmark: rr.bookmark && rr.bookmark !== '-end-' ? rr.bookmark : null }
}

// a small picture for the board picker, as a data URL the page can show
export async function smallPic(url) {
  try {
    const res = await fetch(url, { credentials: 'omit' })
    if (!res.ok) return null
    const blob = await res.blob()
    return `data:${blob.type || 'image/jpeg'};base64,` + (await toBase64Url(blob)).replace(/-/g, '+').replace(/_/g, '/')
  } catch {
    return null
  }
}

// every public board of a Pinterest user, newest first, each with up to three of its pictures
export async function pinBoardsOf(user) {
  const out = []
  let bookmark = null
  do {
    const options = { username: user, page_size: 50, privacy_filter: 'all', sort: 'last_pinned_to', field_set_key: 'profile_grid_item', ...(bookmark && { bookmarks: [bookmark] }) }
    const page = await pinResource('BoardsResource', `/${user}/boards/`, options, 'www/[username]/boards.js')
    for (const b of page.data || []) {
      if (!b || b.type !== 'board' || (b.privacy && b.privacy !== 'public')) continue
      const parts = String(b.url || '').split('/').filter(Boolean)
      if (parts.length < 2) continue
      const pics = ((b.images && b.images['236x']) || []).map(x => x.url).filter(Boolean)
      if (!pics.length && b.image_cover_url) pics.push(b.image_cover_url)
      out.push({ id: String(b.id), user: parts[0], board: parts[1], name: String(b.name || parts[1]), count: b.pin_count || 0, pics: pics.slice(0, 3) })
    }
    bookmark = page.bookmark
  } while (bookmark && out.length < 500)
  await Promise.all(out.map(async b => { b.pics = (await Promise.all(b.pics.map(smallPic))).filter(Boolean) }))
  return out
}

// a board's id, for boards followed from a pasted link
export async function pinBoardId(user, board) {
  const page = await pinResource('BoardResource', `/${user}/${board}/`, { username: user, slug: board, field_set_key: 'detailed' }, 'www/[username]/[slug].js')
  return page.data && page.data.id ? String(page.data.id) : null
}

// one page (up to 50) of a board's pins, in the board's own order
export async function boardPins(b, bookmark) {
  const options = { board_id: b.id, board_url: `/${b.user}/${b.board}/`, page_size: 50, field_set_key: 'react_grid_pin', ...(bookmark && { bookmarks: [bookmark] }) }
  const page = await pinResource('BoardFeedResource', `/${b.user}/${b.board}/`, options, 'www/[username]/[slug].js')
  return { pins: (page.data || []).filter(p => p && p.type === 'pin' && p.id), bookmark: page.bookmark }
}

// Pinterest's embed widget: a board's newest 50 pins for anyone, signed in or not
export async function widgetPins(b) {
  try {
    const res = await fetch(`https://widgets.pinterest.com/v3/pidgets/boards/${b.user}/${b.board}/pins/`, { credentials: 'omit' })
    const pins = res.ok && (await res.json())?.data?.pins
    return Array.isArray(pins) ? pins.filter(p => p && p.id) : []
  } catch {
    return []
  }
}

// ---- YouTube playlists (public or unlisted), read off YouTube's own pages ----
export function playlistIdOf(raw) {
  const s = String(raw || '').trim()
  if (/^(PL|UU|OL|FL)[\w-]{10,}$/.test(s)) return s
  try {
    const u = new URL(/^https?:\/\//.test(s) ? s : 'https://' + s)
    if (!/(^|\.)youtube\.com$|^youtu\.be$/.test(u.hostname)) return null
    const id = u.searchParams.get('list')
    return id && /^[\w-]{10,}$/.test(id) ? id : null
  } catch { return null }
}

function jsonAfter(html, marker) {
  const i = html.indexOf(marker)
  if (i < 0) return null
  const a = html.indexOf('{', i)
  let depth = 0, q = false, j = a
  for (; j < html.length; j++) {
    const c = html[j]
    if (q) { if (c === '\\') j++; else if (c === '"') q = false } else if (c === '"') q = true
    else if (c === '{') depth++
    else if (c === '}' && --depth === 0) break
  }
  try { return JSON.parse(html.slice(a, j + 1)) } catch { return null }
}
const walkJson = (o, f) => { if (Array.isArray(o)) o.forEach(x => walkJson(x, f)); else if (o && typeof o === 'object') { f(o); Object.values(o).forEach(x => walkJson(x, f)) } }
const ytText = t => (t && (t.simpleText || (t.runs || []).map(r => r.text).join('') || t.content)) || ''
const unescapeHtml = s => s.replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>')

// { id, title, owner, total, videos: [{ id, title, author }], covers: [3 small pictures] }; videos YouTube hides (private, deleted) are left out
export async function youtubePlaylist(listId) {
  const res = await fetch(`https://www.youtube.com/playlist?list=${listId}&hl=en`, { credentials: 'omit' })
  if (!res.ok) throw new Error(res.status === 404 ? 'not-found' : `YouTube answered ${res.status}`)
  const html = await res.text()
  const data = jsonAfter(html, 'var ytInitialData = ')
  if (!data) throw new Error('YouTube’s page changed and Dailies can’t read it. Update the extension.')
  const key = (html.match(/"INNERTUBE_CLIENT_VERSION":"([^"]+)"/) || [])[1], vd = (html.match(/"visitorData":"([^"]+)"/) || [])[1]
  const header = data.header && (data.header.playlistHeaderRenderer || data.header.pageHeaderRenderer)
  let title = (data.metadata && data.metadata.playlistMetadataRenderer && data.metadata.playlistMetadataRenderer.title) || ytText(header && header.title) || ''
  const videos = [], seen = new Set()
  let cont = null
  const take = o => walkJson(o, x => {
    const v = x.playlistVideoRenderer
    if (v && v.videoId && !seen.has(v.videoId)) { seen.add(v.videoId); videos.push({ id: v.videoId, title: ytText(v.title), author: ytText(v.shortBylineText) }) }
    const l = x.lockupViewModel
    if (l && l.contentType === 'LOCKUP_CONTENT_TYPE_VIDEO' && l.contentId && !seen.has(l.contentId)) {
      seen.add(l.contentId)
      const rows = (l.metadata && l.metadata.lockupMetadataViewModel && l.metadata.lockupMetadataViewModel.metadata && l.metadata.lockupMetadataViewModel.metadata.contentMetadataViewModel && l.metadata.lockupMetadataViewModel.metadata.contentMetadataViewModel.metadataRows) || []
      videos.push({ id: l.contentId, title: ytText(l.metadata && l.metadata.lockupMetadataViewModel && l.metadata.lockupMetadataViewModel.title), author: ytText(rows[0] && rows[0].metadataParts && rows[0].metadataParts[0] && rows[0].metadataParts[0].text) })
    }
    if (x.continuationCommand && x.continuationCommand.token && !cont) cont = x.continuationCommand.token // the first one is the next page of videos
  })
  take(data)
  for (let pages = 0; cont && pages < 60; pages++) {
    const token = cont; cont = null
    const r = await fetch('https://www.youtube.com/youtubei/v1/browse?prettyPrint=false', {
      method: 'POST', credentials: 'omit',
      headers: { 'Content-Type': 'application/json', 'X-Youtube-Client-Name': '1', 'X-Youtube-Client-Version': key, ...(vd && { 'X-Goog-Visitor-Id': vd }) },
      body: JSON.stringify({ context: { client: { clientName: 'WEB', clientVersion: key, visitorData: vd, hl: 'en' } }, continuation: token }),
    })
    if (!r.ok) break
    take(await r.json())
  }
  const said = Number(((JSON.stringify(header || {}).match(/"(?:numVideosText|videoCountText)"[^}]*?"(?:text|simpleText)":"([\d,]+)/) || [])[1] || '').replace(/,/g, '')) ||
    Number((html.match(/"stats":\[\{"runs":\[\{"text":"([\d,]+)"/) || [])[1]?.replace(/,/g, '')) || videos.length
  if (!videos.length) throw new Error('empty')
  const owner = ytText(header && (header.ownerText || header.byline)) || (videos[0] && videos[0].author) || ''
  const covers = (await Promise.all(videos.slice(0, 3).map(v => smallPic(`https://i.ytimg.com/vi/${v.id}/mqdefault.jpg`)))).filter(Boolean)
  return { id: listId, title: unescapeHtml(title || 'Playlist'), owner: unescapeHtml(owner), total: Math.max(said, videos.length), videos, covers }
}
