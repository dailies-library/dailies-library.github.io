import { DAILIES, newId, collectPage, describe, bestThumb, screenshotThumb, tweetInfo, youtubeInfo, MEDIA_ORIGINS } from './shared.js'
import { sourceInfo } from './sources.js'
import { sourceOf, hostOf, youtubeId, normaliseTags, canonTag, setTagVocab, CATEGORIES, isVague, parseIgCollection } from './source-rules.js'

const $ = s => document.querySelector(s)
const SOCIAL = ['instagram', 'tiktok', 'twitter', 'youtube', 'vimeo', 'pinterest', 'threads']
const asDataUrl = b64url => 'data:image/jpeg;base64,' + b64url.replace(/-/g, '+').replace(/_/g, '/')
let tab, page, details, choice = null, options = []

$('#open').href = DAILIES

// Videos, GIFs and YouTube frames need access to a few media hosts; Chrome may be holding it back
chrome.permissions.contains({ origins: MEDIA_ORIGINS }).then(ok => { $('#perm').hidden = ok })
$('#perm-btn').onclick = async () => {
  const ok = await chrome.permissions.request({ origins: MEDIA_ORIGINS }).catch(() => false)
  $('#perm').hidden = ok
}

// on one of your Instagram saved collections: import every save in it (the extension scrolls the page and copies
// each post's link into Dailies); it's then followed, so new saves come in whenever you open the collection again
function offerIgImport(url) {
  const col = parseIgCollection(url)
  if (!col) return
  $('#igfollow').hidden = false
  $('#igfollow-text').textContent = col.id ? `Import every save in “${col.label}” into Dailies?` : 'Import everything you’ve saved on Instagram into Dailies?'
  $('#igfollow-btn').textContent = 'Import'
  $('#igfollow-btn').onclick = async () => {
    $('#igfollow-btn').disabled = true
    $('#igfollow-btn').textContent = 'Importing…'
    $('#igfollow-text').textContent = 'Scrolling through the collection… keep this tab open.'
    const r = await chrome.runtime.sendMessage({ type: 'ig-import', tabId: tab.id, col }).catch(e => ({ ok: false, error: String(e) }))
    if (!r || !r.ok) { $('#igfollow-btn').disabled = false; $('#igfollow-btn').textContent = 'Try again'; $('#igfollow-text').textContent = 'Couldn’t read this page. Reload the Instagram tab and try again.' }
  }
  chrome.runtime.onMessage.addListener(msg => {
    if (!msg || msg.type !== 'ig-progress' || msg.url !== col.url) return
    $('#igfollow-text').textContent = msg.done
      ? `Done: ${msg.total} saves found, ${msg.added} new sent to Dailies. Open this collection again any time to bring in new saves.`
      : `Found ${msg.total} saves so far…`
    if (msg.done) { $('#igfollow').classList.add('on'); $('#igfollow-btn').textContent = 'Imported ✓' }
  })
}

async function init() {
  ;[tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab || !/^https?:/.test(tab.url || '')) { $('#blocked').hidden = false; return }
  $('#form').hidden = false
  offerIgImport(tab.url)
  const source = sourceOf(tab.url)
  const info = sourceInfo(source)
  $('#glyph').innerHTML = `<svg viewBox="0 0 24 24"><path d="${info.path}"/></svg>`
  $('#src').textContent = `${info.label} · ${hostOf(tab.url)}`
  $('#title').textContent = tab.title || tab.url
  $('#note').focus()
  showRecentTags()

  page = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectPage }).then(r => r[0]?.result).catch(() => null)
  page ||= { url: tab.url, title: tab.title, desc: '', og: '', images: [], selection: '' }
  details = describe(page, source)
  const tweet = source === 'twitter' ? await tweetInfo(page.url) : null
  if (tweet) details = { title: tweet.title, author: tweet.author, caption: tweet.caption, video: tweet.video }
  const yt = source === 'youtube' && youtubeId(page.url) ? await youtubeInfo(page.url) : null
  if (yt) details = { ...yt, video: true }
  if (details.title) $('#title').textContent = details.title
  if (page.selection && !$('#note').value) $('#note').value = `“${page.selection}”\n`
  suggestFromPage([details.title, details.caption, page.title, page.desc, page.selection, page.url].filter(Boolean).join(' '))

  const [auto, shot] = await Promise.all([bestThumb(page, source === 'youtube' ? youtubeId(page.url) : null, tweet && tweet.thumb ? [tweet.thumb] : []), screenshotThumb(tab.windowId)])
  if (auto) options.push({ key: 'page', label: 'Page image', img: auto.img })
  if (shot) options.push({ key: 'shot', label: 'Screenshot', img: shot })
  options.push({ key: 'later', label: 'Fetch later', img: null })
  const preferred = auto ? 'page' : SOCIAL.includes(source) ? 'later' : 'shot'
  $('#picks').innerHTML = '<span class="pthumb"></span>' + options.map(o => `<button type="button" data-k="${o.key}">${o.label}</button>`).join('')
  $('#picks').onclick = e => { const k = e.target.dataset.k; if (k) pick(k) }
  pick(options.some(o => o.key === preferred) ? preferred : options[0].key)
}

function pick(key) {
  choice = options.find(o => o.key === key)
  $('#picks').querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.k === key))
  // slide the white pill under the chosen option
  const on = $('#picks').querySelector(`[data-k="${key}"]`), thumb = $('#picks .pthumb')
  if (on && thumb) { thumb.style.width = on.offsetWidth + 'px'; thumb.style.transform = `translateX(${on.offsetLeft}px)` }
  const preview = $('#preview')
  preview.classList.remove('loading')
  if (choice.img) preview.innerHTML = `<img alt="" src="${asDataUrl(choice.img)}">`
  else preview.innerHTML = '<span class="muted">No picture for now. Dailies fetches a clean thumbnail for it later.</span>'
}

// the done badge: a spinning gradient ring while Dailies files it, then a drawn check (or a shake)
const setTick = state => { $('#tick').dataset.state = state }
// the picture shrinks up towards the toolbar icon as the form gives way to the done badge
function flyAway() {
  const img = $('#preview img')
  const go = () => { $('#form').hidden = true; $('#done').hidden = false }
  if (!img || matchMedia('(prefers-reduced-motion: reduce)').matches) { go(); return Promise.resolve() }
  const r = img.getBoundingClientRect()
  const ghost = Object.assign(img.cloneNode(), { className: 'fly' })
  Object.assign(ghost.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' })
  document.body.append(ghost)
  $('#form').animate([{ opacity: 1 }, { opacity: 0, transform: 'translateY(6px)' }], { duration: 220, easing: 'ease-out', fill: 'forwards' })
  const dx = innerWidth - 40 - (r.left + r.width / 2), dy = -20 - (r.top + r.height / 2)
  const a = ghost.animate([
    { transform: 'none', opacity: 1, borderRadius: '16px' },
    { transform: `translate(${dx * .45}px, ${dy * .35}px) scale(.55) rotate(-4deg)`, opacity: 1, offset: .45 },
    { transform: `translate(${dx}px, ${dy}px) scale(.08) rotate(-10deg)`, opacity: 0, borderRadius: '40px' },
  ], { duration: 620, easing: 'cubic-bezier(.5, 0, .2, 1)' })
  return new Promise(res => setTimeout(() => { go(); res() }, 260)).then(() => a.finished.catch(() => {})).then(() => ghost.remove())
}

// Suggested tags: your Dailies tags whose words (or words that mean the same: "colour grade" → #color)
// appear in the page's title, caption or address, then the tags you used recently
let suggested = []
async function showRecentTags() {
  const { recentTags = [], vocab = [] } = await chrome.storage.local.get(['recentTags', 'vocab'])
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))
  const recent = recentTags.filter(t => !suggested.includes(t)).slice(0, Math.max(4, 10 - suggested.length))
  $('#suggest').innerHTML = suggested.map(t => `<button type="button" class="ai" data-t="${esc(t)}" title="Matches this page">✦ #${esc(t)}</button>`).join('') +
    recent.map(t => `<button type="button" data-t="${esc(t)}">#${esc(t)}</button>`).join('')
  return vocab
}
async function suggestFromPage(text) {
  const { vocab = [] } = await chrome.storage.local.get('vocab')
  if (!text) return
  // your own tags, plus the broad content and film categories (cinematography, title-sequence…), never loose words like 'visuals'
  const count = new Map([...CATEGORIES.map(t => [t, 0]), ...vocab].filter(([t]) => !isVague(t))), score = new Map()
  setTagVocab(vocab.map(v => v[0]))
  const words = String(text).toLowerCase().replace(/[^\p{L}\p{N}#\s-]/gu, ' ').split(/\s+/).filter(Boolean).slice(0, 400)
  const look = w => { const t = canonTag(w); if (count.has(t)) score.set(t, (score.get(t) || 0) + 1) }
  words.forEach((w, i) => { look(w); if (words[i + 1]) look(w + ' ' + words[i + 1]); if (words[i + 2]) look(w + ' ' + words[i + 1] + ' ' + words[i + 2]) })
  suggested = [...score.keys()].sort((a, b) => score.get(b) - score.get(a) || count.get(b) - count.get(a)).slice(0, 4)
  if (suggested.length) showRecentTags()
}
$('#suggest').onclick = e => {
  const t = e.target.dataset.t
  if (!t) return
  const list = $('#tags').value.split(',').map(s => s.trim()).filter(Boolean)
  if (!list.includes(t)) $('#tags').value = [...list, t].join(', ')
  e.target.classList.add('on')
}

$('#form').addEventListener('keydown', e => {
  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); $('#form').requestSubmit() }
})

let pendingId = null
$('#form').addEventListener('submit', async e => {
  e.preventDefault()
  const tags = normaliseTags($('#tags').value)
  const item = {
    id: newId(),
    u: page?.url || tab.url,
    t: details?.title || tab.title || '',
    a: details?.author || '',
    c: details?.caption || '',
    n: $('#note').value.trim(),
    g: tags,
  }
  if (details?.video) item.k = 'video'
  if (choice?.img) item.img = choice.img
  $('#save').disabled = true
  $('#save').textContent = 'Saving…'
  pendingId = item.id
  const { recentTags = [] } = await chrome.storage.local.get('recentTags')
  chrome.storage.local.set({ recentTags: [...new Set([...tags, ...recentTags])].slice(0, 20) })
  let res = null
  try { res = await chrome.runtime.sendMessage({ type: 'enqueue', item }) } catch (e) { res = { ok: false, error: String(e && e.message || e) } }
  if (!res?.ok) { $('#save').disabled = false; $('#save').textContent = 'Save to Dailies'; $('#title').textContent = 'Couldn’t save. ' + (/port closed|context invalidated|receiving end/i.test(res?.error || '') ? 'The extension was just updated: close this and try again.' : String(res?.error || 'Try again.').replace(/^Error:\s*/, '')); return }
  setTick('wait')
  $('#done-text').textContent = 'Adding to Dailies'
  $('#done-sub').textContent = ''
  await flyAway()
  if (res.mac) { // Dailies for Mac took it: it's in the open app now
    pendingId = null
    setTick('ok')
    $('#done-text').textContent = 'Saved to Dailies'
    $('#done-sub').textContent = 'It’s in Dailies for Mac now.'
    setTimeout(() => window.close(), 1500)
    return
  }
  if (!res.live) {
    // Dailies isn't open: the save waits in the extension until you next open it in Chrome.
    pendingId = null
    setTick('ok')
    $('#done-text').textContent = 'Saved'
    $('#done-sub').innerHTML = `It goes into Dailies the next time you open it in Chrome${res.waiting > 1 ? ` (${res.waiting} waiting)` : ''}. <a href="${DAILIES}" target="_blank" rel="noopener">Open now</a>`
    setTimeout(() => window.close(), 2600)
    return
  }
  setTimeout(() => {
    if (pendingId) $('#done-sub').textContent = 'Still working. You can close this; the icon shows ✓ when it’s in.'
  }, 6000)
})

chrome.runtime.onMessage.addListener(msg => {
  if (msg?.type !== 'result' || msg.id !== pendingId) return
  pendingId = null
  if (msg.state === 'error') {
    setTick('err')
    $('#done-text').textContent = 'Couldn’t save'
    $('#done-sub').textContent = msg.message || ''
    return
  }
  setTick('ok')
  $('#done-text').textContent = msg.state === 'duplicate' ? 'Already in Dailies. Note added.' : 'Saved to Dailies'
  $('#done-sub').textContent = ''
  setTimeout(() => window.close(), 1500)
})

init()

// the Save button on posts (hover.js) is on unless turned off here
chrome.storage.local.get('hoverOff').then(({ hoverOff }) => { document.getElementById('hover-on').checked = !hoverOff })
document.getElementById('hover-on').addEventListener('change', e => chrome.storage.local.set({ hoverOff: !e.target.checked }))
