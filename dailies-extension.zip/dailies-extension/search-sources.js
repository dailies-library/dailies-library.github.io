// Searching other places from Dailies: pictures from the whole web, Pinterest pins, YouTube videos.
// Each returns { results: [{ id, title, sub, url, thumb, full?, w?, h? }], next } where thumb is a picture address to preview,
// url is where it lives, and full (web pictures only) is the large picture, fetched only if you save it.
// These read the same public search pages anyone sees in a browser tab; nothing is sent from your library.

const clean = s => String(s ?? '').replace(/\s+/g, ' ').trim()
const dec = s => String(s ?? '').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
const withTimeout = async (url, init = {}, ms = 8000) => {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), ms)
  try { return await fetch(url, { ...init, signal: ctl.signal }) } finally { clearTimeout(t) }
}
const httpsOnly = u => { try { const x = new URL(u); return x.protocol === 'https:' ? x.href : '' } catch { return '' } }

// the whole web, as pictures (DuckDuckGo's image search, the same page you would open in a tab; Bing's page is the back-up)
async function searchDuck(q, page) {
  const first = await withTimeout(`https://duckduckgo.com/?q=${encodeURIComponent(q)}&iax=images&ia=images`, { credentials: 'omit', headers: { 'Accept-Language': 'en-US,en;q=0.9' } })
  const vqd = first.ok && ((await first.text()).match(/vqd=["']?([\d-]+)["']?/) || [])[1]
  if (!vqd) return null
  const res = await withTimeout(`https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(q)}&vqd=${vqd}&f=,,,,,&p=1&s=${page * 40}`, { credentials: 'omit', headers: { Referer: 'https://duckduckgo.com/', Accept: 'application/json' } })
  const j = res.ok && await res.json().catch(() => null)
  if (!j || !Array.isArray(j.results)) return null
  const results = []
  for (const x of j.results) {
    const thumb = httpsOnly(x.thumbnail), full = httpsOnly(x.image), pg = httpsOnly(x.url)
    if (!thumb || !pg) continue
    results.push({ id: 'w:' + (x.thumbnail.match(/id=([\w.\-]+)/) || [])[1] + ':' + (x.image || '').slice(-24), title: clean(x.title).slice(0, 200), sub: new URL(pg).hostname.replace(/^www\./, ''), url: pg, thumb, full, w: x.width, h: x.height })
  }
  return { results, next: results.length >= 20 && page < 5 ? page + 1 : null }
}
async function searchBing(q, page) {
  const res = await withTimeout(`https://www.bing.com/images/search?q=${encodeURIComponent(q)}&first=${1 + page * 35}&count=35&adlt=moderate`, { credentials: 'omit', headers: { 'Accept-Language': 'en-US,en;q=0.9' } })
  if (!res.ok) return { results: [], next: null }
  const html = await res.text()
  const results = []
  for (const m of html.matchAll(/class="iusc"[^>]*\sm="([^"]+)"/g)) {
    let j; try { j = JSON.parse(dec(m[1])) } catch { continue }
    const thumb = httpsOnly(j.turl), full = httpsOnly(j.murl), page_ = httpsOnly(j.purl)
    if (!thumb || !page_) continue
    results.push({ id: 'w:' + (j.mid || j.md5 || full.slice(-40)), title: clean(dec(j.t)).slice(0, 200), sub: new URL(page_).hostname.replace(/^www\./, ''), url: page_, thumb, full })
  }
  return { results, next: results.length >= 20 ? page + 1 : null }
}
export async function searchWeb(q, page = 0) {
  try { const r = await searchDuck(q, page); if (r && r.results.length) return r } catch { /* try the back-up */ }
  return searchBing(q, page)
}

// Pinterest pins (the search Pinterest's own page uses; you get your own results when you are logged in)
export async function searchPinterest(q, bookmark = null) {
  const data = JSON.stringify({ options: { query: q, scope: 'pins', page_size: 25, rs: 'typed', ...(bookmark ? { bookmarks: [bookmark] } : {}) }, context: {} })
  const url = `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=${encodeURIComponent('/search/pins/?q=' + q + '&rs=typed')}&data=${encodeURIComponent(data)}`
  const res = await withTimeout(url, { credentials: 'include', headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-Pinterest-PWS-Handler': 'www/search/[scope].js', Accept: 'application/json' } })
  if (!res.ok) return { results: [], next: null }
  const j = await res.json().catch(() => null)
  const d = j && j.resource_response
  const list = (d && d.data && d.data.results) || []
  const results = []
  for (const p of list) {
    if (!p || p.type !== 'pin' || !p.id || !p.images) continue
    const im = p.images['474x'] || p.images['736x'] || p.images['236x'] || p.images.orig
    if (!im || !im.url) continue
    const title = clean(p.grid_title || p.title || p.seo_alt_text || p.auto_alt_text || p.description)
    results.push({ id: 'p:' + p.id, title: title.slice(0, 200), sub: clean(p.pinner && p.pinner.username ? '@' + p.pinner.username : p.domain), url: `https://www.pinterest.com/pin/${p.id}/`, thumb: httpsOnly(im.url), full: httpsOnly((p.images.orig || im).url), w: im.width, h: im.height })
  }
  const next = d && typeof d.bookmark === 'string' && d.bookmark && d.bookmark !== '-end-' ? d.bookmark : null
  return { results, next: results.length ? next : null }
}

// YouTube videos (the results page everyone sees)
export async function searchYouTube(q) {
  const res = await withTimeout(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, { credentials: 'omit', headers: { 'Accept-Language': 'en-US,en;q=0.9' } })
  if (!res.ok) return { results: [], next: null }
  const html = await res.text()
  const m = html.match(/var ytInitialData = (\{.*?\});<\/script>/s)
  if (!m) return { results: [], next: null }
  let data; try { data = JSON.parse(m[1]) } catch { return { results: [], next: null } }
  const vids = []
  const walk = o => { if (!o || typeof o !== 'object') return; if (o.videoRenderer && o.videoRenderer.videoId) vids.push(o.videoRenderer); for (const v of Array.isArray(o) ? o : Object.values(o)) walk(v) }
  walk(data)
  const seen = new Set(), results = []
  for (const v of vids) {
    if (seen.has(v.videoId)) continue
    seen.add(v.videoId)
    const ths = (v.thumbnail && v.thumbnail.thumbnails) || []
    results.push({ id: 'y:' + v.videoId, title: clean(v.title && v.title.runs && v.title.runs.map(r => r.text).join('')).slice(0, 200), sub: clean((v.ownerText && v.ownerText.runs && v.ownerText.runs[0].text) || '') + (v.lengthText ? ' · ' + v.lengthText.simpleText : ''), url: `https://www.youtube.com/watch?v=${v.videoId}`, thumb: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg` || (ths[ths.length - 1] && ths[ths.length - 1].url), w: 480, h: 360 })
  }
  return { results, next: null }
}

export async function runSearch(scope, q, page) {
  if (scope === 'pinterest') return searchPinterest(q, page || null)
  if (scope === 'youtube') return searchYouTube(q)
  return searchWeb(q, Number.isInteger(page) ? page : 0)
}
