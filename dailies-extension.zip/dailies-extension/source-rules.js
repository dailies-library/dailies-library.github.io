// Where a reference came from, and how to tidy its link.

const HOSTS = [
  ['instagram', ['instagram.com', 'instagr.am']],
  ['twitter', ['twitter.com', 'x.com', 'fxtwitter.com', 'vxtwitter.com', 'fixupx.com', 't.co']],
  ['youtube', ['youtube.com', 'youtu.be', 'youtube-nocookie.com']],
  ['pinterest', ['pinterest.com', 'pin.it']],
  ['tiktok', ['tiktok.com']],
  ['vimeo', ['vimeo.com']],
  ['behance', ['behance.net']],
  ['dribbble', ['dribbble.com']],
  ['reddit', ['reddit.com', 'redd.it']],
  ['threads', ['threads.net', 'threads.com']],
  ['linkedin', ['linkedin.com', 'lnkd.in']],
  ['facebook', ['facebook.com', 'fb.watch', 'fb.com']],
  ['artstation', ['artstation.com']],
  ['figma', ['figma.com']],
  ['github', ['github.com']],
  ['medium', ['medium.com']],
  ['arena', ['are.na']],
  ['tumblr', ['tumblr.com']],
  ['spotify', ['spotify.com']],
  ['unsplash', ['unsplash.com']],
  ['savee', ['savee.it', 'savee.com']],
  ['cosmos', ['cosmos.so']],
  ['awwwards', ['awwwards.com']],
]

// pinterest.co.uk, pinterest.de, … all count as Pinterest
const PINTEREST_TLD = /(^|\.)pinterest\.[a-z.]+$/

const SHORTENERS = new Set([
  'pin.it', 't.co', 'bit.ly', 'tinyurl.com', 'vm.tiktok.com', 'vt.tiktok.com', 'redd.it',
  'lnkd.in', 'fb.watch', 'instagr.am', 'buff.ly', 'ow.ly', 'shorturl.at', 'is.gd', 'spoti.fi',
])

const TRACKING = /^(utm_.*|igsh|igshid|fbclid|gclid|dclid|mc_cid|mc_eid|si|ref_src|ref_url|mibextid|rdt|share_id|is_from_webapp|sender_device|share_app_id|share_link_id|tt_from|u_code|social_sharing|tracking_source|igsi|stkn)$/i

export function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\.|^m\.|^mobile\./, '').toLowerCase() } catch { return '' }
}

export function sourceOf(url) {
  const host = hostOf(url)
  if (!host) return 'web'
  if (PINTEREST_TLD.test(host)) return 'pinterest'
  for (const [name, hosts] of HOSTS) {
    if (hosts.some(h => host === h || host.endsWith('.' + h))) return name
  }
  return 'web'
}

export function isShortLink(url) {
  return SHORTENERS.has(hostOf(url))
}

export function youtubeId(url) {
  try {
    const u = new URL(url)
    const host = u.hostname.replace(/^www\.|^m\.|^music\./, '')
    if (host === 'youtu.be') return u.pathname.slice(1).split('/')[0] || null
    if (u.searchParams.get('v')) return u.searchParams.get('v')
    const m = u.pathname.match(/^\/(shorts|embed|live|v)\/([\w-]{6,})/)
    return m ? m[2] : null
  } catch { return null }
}

export function tweetId(url) {
  const m = String(url).match(/\/status(?:es)?\/(\d+)/)
  return m ? m[1] : null
}

export function instagramCode(url) {
  const m = String(url).match(/instagram\.com\/(?:[\w.]+\/)?(?:p|reel|reels|tv)\/([\w-]+)/)
  return m ? m[1] : null
}

// Strip tracking junk and normalise hosts so the same post shared twice is recognised.
export function cleanUrl(raw) {
  let u
  try { u = new URL(String(raw).trim()) } catch { return String(raw).trim() }
  if (!/^https?:$/.test(u.protocol)) return u.toString()
  u.protocol = 'https:'
  const source = sourceOf(u.toString())
  for (const k of [...u.searchParams.keys()]) {
    if (TRACKING.test(k)) u.searchParams.delete(k)
  }
  if (source === 'twitter') {
    const id = tweetId(u.pathname)
    if (id) {
      const user = u.pathname.split('/')[1] || 'i'
      return `https://x.com/${user}/status/${id}`
    }
    u.hostname = 'x.com'
    u.search = ''
  }
  if (source === 'instagram') {
    u.hostname = 'www.instagram.com'
    const keep = u.searchParams.get('img_index')
    u.search = keep ? `?img_index=${keep}` : ''
    u.hash = ''
  }
  if (source === 'youtube') {
    const id = youtubeId(u.toString())
    if (id) {
      const isShort = u.pathname.startsWith('/shorts/')
      const t = u.searchParams.get('t') || u.searchParams.get('start')
      if (isShort) return `https://www.youtube.com/shorts/${id}`
      return `https://www.youtube.com/watch?v=${id}${t ? `&t=${t}` : ''}`
    }
  }
  if (source === 'pinterest' && u.hostname !== 'pin.it') {
    u.hostname = 'www.pinterest.com'
    u.search = ''
  }
  if (source === 'tiktok' || source === 'threads' || source === 'reddit') u.search = ''
  if ([...u.searchParams.keys()].length === 0) u.search = ''
  if (u.hostname.startsWith('m.') && ['youtube', 'facebook', 'reddit'].includes(source)) u.hostname = 'www.' + u.hostname.slice(2)
  return u.toString()
}

// Same post, different link formats (x.com/i/status vs x.com/user/status) → same key.
export function dedupeKey(url) {
  const source = sourceOf(url)
  if (source === 'twitter' && tweetId(url)) return `x:${tweetId(url)}`
  if (source === 'instagram' && instagramCode(url)) return `ig:${instagramCode(url)}`
  if (source === 'youtube' && youtubeId(url)) return `yt:${youtubeId(url)}`
  return url
}

// Pull every link out of a chunk of text (Slack wraps links as <url|label> or <url>).
export function extractUrls(text) {
  const found = []
  const s = String(text || '')
  for (const m of s.matchAll(/<(https?:\/\/[^>|\s]+)(?:\|[^>]*)?>/g)) found.push(m[1])
  const plain = s.replace(/<[^>]+>/g, ' ')
  for (const m of plain.matchAll(/https?:\/\/[^\s<>"')\]]+/g)) found.push(m[0].replace(/[.,;:!?]+$/, ''))
  return [...new Set(found.map(decodeSlack))]
}

export function decodeSlack(s) {
  return String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
}

// What's left of a Slack message once links are removed: hashtags become tags, the rest is the note.
export function splitNote(text) {
  let s = String(text || '')
  s = s.replace(/<(https?:\/\/[^>]+)>/g, ' ')
  s = s.replace(/<@[A-Z0-9]+(\|[^>]*)?>/g, ' ')
  s = s.replace(/<#[A-Z0-9]+\|([^>]*)>/g, (_, name) => name ? `#${name}` : ' ')
  s = s.replace(/<![^>]+>/g, ' ')
  s = s.replace(/https?:\/\/\S+/g, ' ')
  s = decodeSlack(s)
  const tags = []
  s = s.replace(/(^|\s)#([\p{L}\p{N}_-]{1,40})/gu, (_, pre, tag) => { tags.push(canonTag(tag)); return pre })
  let note = s.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim()
  // "<link> and <link>" leaves just a joining word behind; that's not a note
  if (/^[\s,.;:&+|/\-–—]*(and|or|also|plus|&|\+)?[\s,.;:&+|/\-–—]*$/i.test(note)) note = ''
  return { note, tags: [...new Set(tags.filter(Boolean))] }
}

// Tags mean the same thing however they're written: "Colour grade", "#colorgrading" and "LUT" all land on
// #color. Each line is the tag we keep, then the ways people write it. Anything not listed is kept as
// typed, except that it snaps to an existing tag spelled the same apart from dashes and plurals
// (#textanimation → #text-animation) once the page or extension has told us your tags (setTagVocab).
const TAG_SYNONYMS = {
  'color-grade': 'color color-grading colour-grade colour-grading colorgrade colourgrade grading grade color-correction colour-correction color-palette colour-palette palette palettes lut luts colour colours colors color-theory color-scheme colour-scheme',
  'text-animation': 'textanimation animated-text kinetic-type kinetic-typography kinetictype kinetic-text type-animation typography-animation text-effect text-effects moving-type motion-type title-animation text-motion',
  'typography': 'type fonts font typeface typefaces lettering type-design',
  'motion-graphics': 'motiongraphics motion-graphic mograph motion-design motiondesign motion',
  'transition': 'transitions seamless-transition seamless-transitions scene-transition scene-transitions',
  'cinematography': 'footage shots shot framing camera-work camerawork camera-movement lighting composition b-roll broll film-stills film-still cinematic',
  'title-sequence': 'title-sequences opening-titles opening-title main-title main-titles title-design end-credits credits',
  'music-video': 'music-videos musicvideo mv',
  'short-film': 'short-films shortfilm',
  'documentary': 'documentaries docu interview interviews',
  'trailer': 'trailers teaser teasers',
  'storyboard': 'storyboards animatic',
  'poster': 'posters key-art keyart one-sheet',
  'vfx': 'visual-effects visualeffects compositing cgi effects effect special-effects',
  'rotoscope': 'rotoscoping roto',
  '3d': '3d-animation 3d-render 3d-renders three-d blender c4d cinema4d',
  'editing': 'video-editing edit edits editing-technique editing-techniques cuts video-edit',
  'tutorial': 'tutorials how-to howto guide guides walkthrough breakdown breakdowns making-of behind-the-scenes bts',
  'carousel': 'carousels carousel-post carousel-posts insta-carousel slides',
  'web-design': 'website websites webdesign web landing-page landing-pages',
  'ui': 'ui-design ux ui-ux uiux interface app-design app-ui',
  'inspiration': 'inspo insp inspirations references ideas',
  'branding': 'brand brand-identity identity visual-identity',
  'logo': 'logos logotype',
  'commercial': 'ad ads advert adverts advertisement advertising commercials tvc',
  'illustration': 'illustrations illo drawing drawings',
  'animation': 'animations animated anim',
  'music': 'songs song audio soundtrack',
  'sound-design': 'sfx sound-effects sounddesign',
  'photography': 'photo photos photograph photographs',
  'gradient': 'gradients',
  'glitch': 'glitches glitch-effect',
  'grain': 'film-grain grainy',
  'collage': 'collages',
  'template': 'templates template-pack presets preset',
  'ai': 'ai-art ai-generated generative-ai genai',
}
// The broad content and film-craft categories Claude files references under (next to your own tags)
export const CATEGORIES = ['cinematography', 'editing', 'transition', 'color-grade', 'vfx', 'motion-graphics', 'text-animation', 'typography', 'title-sequence', 'animation', '3d', 'sound-design', 'music-video', 'commercial', 'trailer', 'short-film', 'documentary', 'storyboard', 'branding', 'poster', 'photography', 'illustration', 'ui', 'web-design', 'presentation', 'carousel', 'tutorial', 'template', 'ai']
// words too loose to be a category (everything here is visual, an effect, inspiration…)
const VAGUE = new Set('visuals visual visually aesthetic aesthetics vibe vibes design designs designer art arts artwork creative creativity content video videos image images picture pictures media misc other others stuff cool nice good beautiful style styles reference references inspiration inspo idea ideas edit-ideas trending viral'.split(' '))
export const isVague = t => !t || VAGUE.has(t) || VAGUE.has(t.replace(/s$/, ''))
const SYN = new Map()
const squash = t => t.replace(/-/g, '')
for (const [keep, alts] of Object.entries(TAG_SYNONYMS)) for (const t of [keep, ...alts.split(' ')]) { SYN.set(t, keep); SYN.set(squash(t), keep) }
let VOCAB = new Map() // squashed spelling → your tag
const singular = t => t.length > 4 && /[^s]s$/.test(t) ? t.slice(0, -1) : t.endsWith('ies') && t.length > 5 ? t.slice(0, -3) + 'y' : t
export function setTagVocab(tags) { VOCAB = new Map(); for (const t of tags) { VOCAB.set(squash(singular(t)), t); VOCAB.set(squash(t), t) } }
export function canonTag(raw) {
  const t = String(raw || '').trim().replace(/^#+/, '').toLowerCase().replace(/[\s_/]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').replace(/colour/g, 'color').replace(/grey/g, 'gray').slice(0, 40)
  if (!t) return ''
  for (const c of [t, squash(t), singular(t), squash(singular(t))]) if (SYN.has(c)) return SYN.get(c)
  for (const c of [squash(t), squash(singular(t))]) if (VOCAB.has(c)) return VOCAB.get(c)
  return t
}

export function normaliseTags(tags) {
  const list = Array.isArray(tags) ? tags : String(tags || '').split(/[,\s]+/)
  return [...new Set(list.map(canonTag).filter(Boolean))].slice(0, 20)
}

// instagram.com/<you>/saved/<name>/<id>/ follows one saved collection; instagram.com/<you>/saved/ (or …/all-posts/) follows everything you save
export function parseIgCollection(raw) {
  try {
    const s = String(raw || '').trim()
    const u = new URL(/^https?:\/\//i.test(s) ? s : 'https://' + s)
    if (!/(^|\.)instagram\.com$/.test(u.hostname)) return null
    const parts = u.pathname.split('/').filter(Boolean).map(decodeURIComponent)
    if (parts[1] !== 'saved' || !/^[\w.]+$/.test(parts[0])) return null
    const user = parts[0], id = /^\d{5,}$/.test(parts[3] || '') ? parts[3] : null
    const slug = id ? parts[2] : 'all-posts'
    if (!id && parts[2] && parts[2] !== 'all-posts') return null
    return { user, id, slug, url: `https://www.instagram.com/${user}/saved/${slug}/${id ? id + '/' : ''}`, label: id ? slug.replace(/[-_]+/g, ' ').trim() : 'Instagram saved' }
  } catch { return null }
}
