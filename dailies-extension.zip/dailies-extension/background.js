// Keeps a queue of saves and hands them to Dailies: to Dailies for Mac when that app is open on this Mac
// (it listens on 127.0.0.1:47811), otherwise to the Dailies page on claude.ai through bridge.js.
// It never opens Dailies itself: saves wait here (the icon shows how many) until one of them is open.
import { canFetch, ytShortThumbs, DAILIES, DAILIES_SITES, DAILIES_CLAUDE, newId, fetchThumb, fetchMore, tweetSlides, igSlideUrls, igPostInfo, pinFull, picKeyOf, VIDEO_PREVIEWS, screenshotThumb, collectPage, describe, bestThumb, tweetInfo, youtubeInfo, instagramCover, pinMedia, mediaOfPin, pinBoardsOf, pinBoardId, boardPins, widgetPins, youtubePlaylist, playlistIdOf, smallPic, youtubeScrub, tweetVideo, igVideoUrl, videoFrames } from './shared.js'
import { sourceOf, youtubeId, parseIgCollection, cleanUrl, instagramCode } from './source-rules.js'
import { sitePage, publicHost } from './site-preview.js'
import { runSearch } from './search-sources.js'

const ports = new Set()

// Everything the Dailies page sends here is checked and rebuilt before it is used: the page runs inside claude.ai or the
// website, and the extension has your Pinterest and Instagram login, so it only ever opens addresses it builds itself.
const cleanBoards = list => (Array.isArray(list) ? list : []).slice(0, 200).flatMap(b => {
  if (!b || typeof b.user !== 'string' || !/^[\w.-]{1,60}$/.test(b.user)) return []
  const board = typeof b.board === 'string' && b.board ? b.board : null
  if (board && !/^[\w%.-]{1,160}$/.test(board)) return []
  return [{ user: b.user, board, url: `https://www.pinterest.com/${b.user}/${board ? board + '/' : ''}`, label: String(b.label || board || b.user).slice(0, 120), id: /^\d{5,25}$/.test(String(b.id || '')) ? String(b.id) : null, count: Math.max(0, Math.min(1e6, +b.count || 0)) }]
})
const cleanIgCols = list => (Array.isArray(list) ? list : []).slice(0, 100).flatMap(c => { const col = c && typeof c.url === 'string' ? parseIgCollection(c.url) : null; return col ? [col] : [] })
let stopStamp = 0 // "Stop" in the import panel: loops that started before this moment end
const getQueue = async () => (await chrome.storage.local.get('queue')).queue || []
const setQueue = queue => chrome.storage.local.set({ queue })
// every change to the queue goes one at a time: a delivered save being removed and a new batch being added used to overwrite each other,
// which put already-delivered saves back in the queue so they were delivered again (and a deleted reference came back)
let queueChain = Promise.resolve()
const updateQueue = fn => { const run = queueChain.then(async () => { const next = fn(await getQueue()); await setQueue(next); return next }); queueChain = run.catch(() => {}); return run }

function badge(text, color, clearAfter) {
  chrome.action.setBadgeBackgroundColor({ color })
  chrome.action.setBadgeText({ text })
  if (clearAfter) setTimeout(() => chrome.action.setBadgeText({ text: '' }), clearAfter)
}

async function showPending() {
  const queue = await getQueue()
  if (queue.length && !ports.size) badge(String(queue.length), '#5b6cff')
  else if (!queue.length) chrome.action.setBadgeText({ text: '' })
}

async function enqueue(item) {
  await updateQueue(q => q.some(i => i.id === item.id) ? q : [...q, item])
  if (!ports.size) await wakeDailies() // an open Dailies whose link dropped while this worker slept reconnects in a moment
  const mac = await deliver()
  await showPending()
  return mac
}
// asks open Dailies tabs to reopen their link, and gives them a moment to do it
async function wakeDailies() {
  const tabs = await chrome.tabs.query({ url: [...DAILIES_SITES.map(s => s + '*'), DAILIES_CLAUDE + '*'] }).catch(() => [])
  if (!tabs.length) return
  for (const t of tabs) chrome.tabs.sendMessage(t.id, { type: 'reconnect' }).catch(() => {})
  for (let i = 0; i < 8 && !ports.size; i++) await new Promise(r => setTimeout(r, 100))
}

// Pins read for one Dailies (the website, or your claude.ai one) are marked `to` and go only to that one; everything else
// goes to the open website first, else any open Dailies, else the Mac app
const sentTo = new WeakMap() // port → Map(item id → when it was handed over), so an item isn't sent again before Dailies had a chance to answer
const RESEND_AFTER = 60e3
async function deliver() {
  const queue = await getQueue()
  if (!queue.length) return false
  const main = [...ports].find(p => p.web) || [...ports][0]
  const kindOpen = kind => [...ports].some(p => (kind === 'web') === !!p.web)
  // pins read for one Dailies go to that one while it is around; once it isn't, any open Dailies may have them (they used to wait forever)
  const forPort = p => queue.filter(i => !i.to ? p === main : ((i.to === 'web') === !!p.web) || (!kindOpen(i.to) && p === main))
  let mac = false
  if (!(main && main.web) && await macApp()) { const mine = queue.filter(i => i.to !== 'web'); if (mine.length && await sendToMac(mine)) mac = true }
  const now = Date.now()
  let soonest = Infinity
  for (const p of ports) {
    const sent = sentTo.get(p) || sentTo.set(p, new Map()).get(p)
    for (const item of forPort(p)) {
      const age = now - (sent.get(item.id) || 0)
      if (age < RESEND_AFTER) { soonest = Math.min(soonest, RESEND_AFTER - age); continue }
      try { p.postMessage({ type: 'items', items: [item] }); sent.set(item.id, now) } // one at a time: a batch of big pictures or videos could exceed Chrome's message size
      catch (e) { console.warn('Dailies tab did not take a save', e); break }
    }
  }
  if (soonest < Infinity) { clearTimeout(redeliverTimer); redeliverTimer = setTimeout(() => deliver().then(showPending), soonest + 100) }
  return mac
}
let redeliverTimer = 0
// what the extension remembers about your boards is kept apart for each Dailies: the website and claude.ai are separate libraries
const pinKeys = port => { const web = !!(port && port.web), x = web ? ':web' : ''; return { to: web ? 'web' : 'claude', boards: 'boards' + x, at: 'pinSyncAt' + x, seen: 'seenPins' + x, done: 'pinDone' + x } }

// ---- Dailies for Mac ----
const MAC = 'http://127.0.0.1:47811'
let macUp = false, macCheckedAt = 0
async function macApp() {
  if (Date.now() - macCheckedAt < 3000) return macUp
  macCheckedAt = Date.now()
  try { macUp = (await fetch(MAC + '/ping', { signal: AbortSignal.timeout(1000) })).ok } catch { macUp = false }
  return macUp
}
// the app keeps them in its inbox until its page has stored each one, so once it says yes they're its job
async function sendToMac(items) {
  try {
    const r = await fetch(MAC + '/save', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(items), signal: AbortSignal.timeout(20000) })
    if (!r.ok) return false
    const sent = new Set(items.map(i => i.id))
    const queue = await updateQueue(q => q.filter(i => !sent.has(i.id)))
    if (!queue.length) badge('✓', '#2fb67c', 2500)
    return true
  } catch { macUp = false; return false }
}
// saves made while the app was closed go over once it opens
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'dailies-mac') deliver().then(showPending) }) // (Instagram is never looked at on a timer)
chrome.alarms.create('dailies-mac', { periodInMinutes: 1 })

chrome.runtime.onStartup.addListener(() => deliver().then(showPending))

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'dailies') return
  const from = port.sender?.url || '', tabUrl = port.sender?.tab?.url || ''
  // the frame that connects must be the Dailies page, or the claude.ai frame inside the Dailies artifact's own tab
  const onSite = u => DAILIES_SITES.some(s => u === s || u.startsWith(s + '?') || u.startsWith(s + '#') || u.startsWith(s + 'index.html')) // the Dailies page only, not another page on the same site
  const okWeb = onSite(from)
  const okClaude = /^https:\/\/([\w-]+\.)+frame\.claudeusercontent\.com\//.test(from) && (tabUrl === DAILIES_CLAUDE || tabUrl.startsWith(DAILIES_CLAUDE + '?') || tabUrl.startsWith(DAILIES_CLAUDE + '/') || tabUrl.startsWith(DAILIES_CLAUDE + '#'))
  if (!okWeb && !okClaude) { port.disconnect(); return }
  port.web = okWeb
  ports.add(port)
  port.onDisconnect.addListener(() => ports.delete(port))
  port.onMessage.addListener(msg => {
    if (msg && msg.type === 'boards') onBoards(cleanBoards(msg.boards), port, msg.force === true)
    else if (msg && msg.type === 'pinuser') onPinUser(msg, port)
    else if (msg && msg.type === 'ytlist') onYtList(msg, port)
    else if (msg && msg.type === 'iglist') onIgList(msg, port)
    else if (msg && msg.type === 'igimport') onIgImport({ cols: cleanIgCols(msg.cols) }, port)
    else if (msg && msg.type === 'stop') onStop()
    else if (msg && msg.type === 'have-result') { const w = haveWaiters.get(msg.nonce); if (w) { haveWaiters.delete(msg.nonce); w(msg.have || []) } }
    else if (msg && msg.type === 'igcols') onIgCollections(cleanIgCols(msg.cols), !!msg.force || !!msg.visit)
    else if (msg && msg.type === 'enrich') enrichAll(msg.items || [], port)
    else if (msg && msg.type === 'peek') onPeek(msg, port)
    else if (msg && msg.type === 'search') onSearch(msg, port)
    else if (msg && msg.type === 'pickimage') onPickImage(msg, port)
    else if (msg && msg.type === 'vocab') chrome.storage.local.set({ vocab: (msg.tags || []).slice(0, 200) }) // your tags, for suggestions in the popup
    else onResult(msg)
  })
  port.onDisconnect.addListener(showPending)
  deliver()
  sendIgFollows()
  igPausedUntil().then(until => { if (until) try { port.postMessage({ type: 'ig-pause', until }) } catch {} })
  chrome.storage.local.get('igStatus').then(({ igStatus }) => { if (igStatus) try { port.postMessage({ type: 'ig-status', status: igStatus }) } catch {} })
})

async function onResult(msg) {
  if (!msg || msg.type !== 'dailies:result') return
  for (const p of ports) { const m = sentTo.get(p); if (m) m.delete(msg.id) } // answered: if it is ever queued again, it goes straight away
  const failed = msg.state === 'error'
  const queue = await updateQueue(q => q.flatMap(i => i.id !== msg.id ? [i] : failed && (i.tries || 0) < 2 ? [{ ...i, tries: (i.tries || 0) + 1, err: String(msg.message || '').slice(0, 200) }] : []))
  chrome.runtime.sendMessage({ type: 'result', id: msg.id, state: msg.state, message: msg.message }).catch(() => {})
  if (msg.state === 'error') badge('!', '#e5484d', 6000)
  else if (!queue.length) badge('✓', '#2fb67c', 2500)
}

const HOVER_SITE = /^https:\/\/([\w-]+\.)*(instagram\.com|x\.com|twitter\.com|pinterest\.[a-z.]+|youtube\.com|behance\.net|dribbble\.com|are\.na|tumblr\.com|cosmos\.so|savee\.it|savee\.com)\//
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  const fromPopup = !_sender.tab && _sender.id === chrome.runtime.id
  const fromIg = /^https:\/\/www\.instagram\.com\//.test(_sender.url || '')
  if (['ig-follow', 'ig-import', 'enqueue'].includes(msg?.type) && !fromPopup) return // only the extension's own popup asks for these
  if (['ig-links', 'ig-visit'].includes(msg?.type) && !fromIg) return
  if (msg?.type === 'save-post' && !HOVER_SITE.test(_sender.url || '')) return // the Save button only exists on these sites (hover.js)
  if (msg?.type === 'status') { Promise.all([getQueue(), macApp()]).then(([q, mac]) => reply({ waiting: q.length, live: ports.size > 0 || mac, mac })); return true }
  if (msg?.type === 'ig-follow') { followIg(msg.col).then(() => reply({ ok: true, live: ports.size > 0 })); return true }
  if (msg?.type === 'ig-import') { followIg(msg.col).then(() => startIgImport(msg.tabId)).then(() => reply({ ok: true, live: ports.size > 0 }), e => reply({ ok: false, error: String(e.message || e) })); return true }
  if (msg?.type === 'ig-links') { onIgLinks(msg, _sender.tab).then(() => reply({ ok: true }), () => reply({ ok: false })); return true }
  if (msg?.type === 'ig-visit') { onIgVisit(msg.url, _sender.tab); return }
  if (msg?.type === 'save-post') { savePost(msg.post).then(reply, e => reply({ ok: false, error: String(e && e.message || e) })); return true }
  if (msg?.type !== 'enqueue') return
  enqueue(msg.item).then(async mac => reply({ ok: true, mac, live: mac || ports.size > 0, waiting: (await getQueue()).length }), e => reply({ ok: false, error: String(e) }))
  return true
})

// ---- the Save button on posts (hover.js): one post, saved the way the right-click menu saves a page ----
// Only what the button sends is used, and only after checking it: an http(s) address and, optionally, an http(s) picture.
async function savePost(p) {
  const raw = p && typeof p.url === 'string' ? p.url.slice(0, 2000) : ''
  if (!/^https?:\/\//.test(raw)) throw new Error('not a link')
  const url = cleanUrl(raw)
  const source = sourceOf(url)
  const pic = typeof p.img === 'string' && /^https?:\/\//.test(p.img) ? p.img.slice(0, 2000) : ''
  const tweet = source === 'twitter' ? await tweetInfo(url) : null
  const ytId = source === 'youtube' ? youtubeId(url) : null
  const yt = ytId ? await youtubeInfo(url) : null
  const d = tweet || yt || {}
  // Pinterest's picture descriptions start with "This may contain:"; the rest describes the pin well enough for a title
  const hint = String(p.title || '').replace(/^this may contain:?\s*/i, '').slice(0, 300)
  const item = { id: newId(), u: url, t: d.title || (hint && hint[0].toUpperCase() + hint.slice(1)), a: d.author || '', c: d.caption || '' }
  if ((tweet && tweet.video) || (source === 'twitter' && p.video)) item.k = 'video'
  const short = ytId && /\/shorts\//.test(url)
  const pics = [...(short ? ytShortThumbs(ytId) : []), tweet && tweet.thumb, pic, instagramCover(url), ytId && `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg`, ytId && `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`].filter(Boolean)
  for (const src of pics) { item.img = await fetchThumb(src); if (item.img) break }
  if (!item.img) delete item.img // Dailies fetches a preview itself
  const mac = await enqueue(item)
  return { ok: true, live: mac || ports.size > 0, waiting: (await getQueue()).length }
}

// After an update or a reload, Dailies pages that were already open still run the old bridge, which can't reach the
// new extension. Add the new bridge to them, so they reconnect without anyone reloading the page.
// the same for the Save button on posts: open tabs on the sites it knows get the new one (the old one has stepped aside)
const HOVER_SITES = ['*://*.instagram.com/*', '*://*.x.com/*', '*://x.com/*', '*://*.twitter.com/*', '*://*.pinterest.com/*', '*://*.youtube.com/*', '*://*.behance.net/*', '*://*.dribbble.com/*', '*://dribbble.com/*', '*://*.are.na/*', '*://*.tumblr.com/*', '*://*.cosmos.so/*', '*://*.savee.it/*', '*://*.savee.com/*']
async function rejoinHover() {
  const tabs = await chrome.tabs.query({ url: HOVER_SITES }).catch(() => [])
  for (const t of tabs) if (/^https:/.test(t.url || '')) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['hover.js'] }).catch(() => {})
}
async function rejoinOpenDailies() {
  const tabs = await chrome.tabs.query({ url: [...DAILIES_SITES.map(s => s + '*'), DAILIES_CLAUDE + '*'] }).catch(() => [])
  for (const t of tabs) chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['bridge.js'] }).catch(() => {})
}

// ---- right-click menu ----
// 1.38.1 (25 Oct 2026): a one-time fresh start. What the extension remembered about pins, saves and collections already
// seen belonged to libraries that were emptied, and would have made the same boards look as if they had nothing new.
const FRESH_START_AT = '1.38.3'
const olderThan = (a, b) => { const x = String(a || '0').split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0) } return false }
chrome.runtime.onInstalled.addListener(details => {
  if (details && details.reason === 'update' && olderThan(details.previousVersion, FRESH_START_AT)) {
    chrome.storage.local.remove(['seenPins', 'seenPins:web', 'pinDone', 'pinDone:web', 'pinSyncAt', 'pinSyncAt:web', 'boards', 'boards:web', 'seenIg', 'igCols', 'igFollow', 'igSyncAt', 'hoverSaved', 'tabPeeked']).catch(() => {})
    chrome.storage.session.clear().catch(() => {})
  }
  rejoinOpenDailies()
  rejoinHover()
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'page', title: 'Save page to Dailies', contexts: ['page'] })
    chrome.contextMenus.create({ id: 'link', title: 'Save link to Dailies', contexts: ['link'] })
    chrome.contextMenus.create({ id: 'image', title: 'Save image to Dailies', contexts: ['image'] })
    chrome.contextMenus.create({ id: 'open', title: 'Open Dailies', contexts: ['action'] })
  })
  showPending()
})

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'open') return chrome.tabs.create({ url: DAILIES })
  const item = { id: newId() }
  if (info.menuItemId === 'image') {
    Object.assign(item, { k: 'image', u: info.linkUrl || info.pageUrl, t: tab?.title || '' })
    item.img = (await fetchThumb(info.srcUrl)) || (await screenshotThumb(tab?.windowId))
  } else if (info.menuItemId === 'link') {
    Object.assign(item, { u: info.linkUrl, t: info.selectionText || '' })
  } else {
    const page = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectPage }).then(r => r[0]?.result).catch(() => null)
    const url = page?.url || info.pageUrl
    const source = sourceOf(url)
    const tweet = source === 'twitter' ? await tweetInfo(url) : null
    const yt = source === 'youtube' && youtubeId(url) ? await youtubeInfo(url) : null
    const d = tweet || yt || describe(page || { title: tab?.title }, source)
    Object.assign(item, { u: url, t: d.title, a: d.author, c: d.caption }, tweet && tweet.video ? { k: 'video' } : {})
    // social posts get a clean thumbnail from Claude's preview refresh instead of a screenshot of the site
    const social = ['instagram', 'tiktok', 'twitter', 'youtube', 'vimeo', 'pinterest', 'threads'].includes(source)
    item.img = (page && (await bestThumb(page, source === 'youtube' ? youtubeId(url) : null, [tweet && tweet.thumb, instagramCover(url)].filter(Boolean)))?.img) || (social ? undefined : await screenshotThumb(tab?.windowId))
  }
  enqueue(item)
})

// ---- Pinterest: Dailies tells us which boards to follow; we read them whenever Dailies is open and pass new pins along.
// The first look at a board brings in all of its pins; later looks stop at the first page with nothing new.
// A followed profile (pinterest.com/<user>/ on its own) still reads that profile's feed of its latest 25 pins.
let pinForcedAt = 0
async function onBoards(boards, port, refresh = false) {
  const K = pinKeys(port)
  const before = (await chrome.storage.local.get(K.boards))[K.boards] || []
  const changed = JSON.stringify(before.map(b => b.url)) !== JSON.stringify(boards.map(b => b.url))
  // a board that wasn't followed a moment ago is read whole, even if its pins were seen before (the library may have been emptied)
  const fresh = new Set(boards.filter(b => !before.some(x => x.url === b.url)).map(b => b.url))
  await chrome.storage.local.set({ [K.boards]: boards })
  // Refresh in Dailies reads the boards now (at most once a minute); otherwise every 10 minutes while Dailies is open
  const now = !changed && refresh && Date.now() - pinForcedAt > 60e3
  if (now) pinForcedAt = Date.now()
  await syncPinterest(changed || now, port, fresh)
}
const pinAgain = new Map() // a forced read that arrived while one was running: run once more when it ends

// "Find boards" in Dailies: every public board of a username
async function onPinUser(msg, port) {
  let reply
  try {
    if (typeof msg.user !== 'string' || !/^[\w.-]{1,40}$/.test(msg.user)) throw new Error('not-found')
    reply = { boards: await pinBoardsOf(msg.user) }
  } catch (e) {
    reply = { error: e.message === 'not-found' ? 'not-found' : String(e.message || e) }
  }
  try { port.postMessage({ type: 'pinuser', nonce: msg.nonce, user: msg.user, ...reply }) } catch { /* Dailies was closed */ }
}

// "Import → YouTube": every video of a playlist link
function onStop() {
  stopStamp = Date.now()
  pinAgain.clear() // boards waiting for their turn don't start either
  // pins already read but not yet saved are dropped, so nothing keeps arriving after Stop (Rohit, 26 Oct: "I clicked stop but it's still importing")
  updateQueue(q => q.filter(i => i.k !== 'pin')).then(() => showPending && showPending()).catch(() => {})
  if (igImportTab != null) chrome.tabs.remove(igImportTab).catch(() => {}) // the Instagram tab we opened
}

async function onYtList(msg, port) {
  let reply
  try {
    const id = playlistIdOf(msg.link)
    if (!id) throw new Error('not-a-playlist')
    reply = { list: await youtubePlaylist(id) }
  } catch (e) { reply = { error: e.message === 'empty' ? 'empty' : e.message } }
  try { port.postMessage({ type: 'ytlist', nonce: msg.nonce, ...reply }) } catch { /* Dailies was closed */ }
}

const decode = s => s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&')
  // pin text is escaped twice in the feed, so decode once more for apostrophes, emoji and the like
  .replace(/&apos;/g, "'").replace(/&nbsp;/g, ' ').replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d)).replace(/&amp;/g, '&')

function parseFeed(xml) {
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map(m => {
    const get = tag => decode((m[1].match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`)) || [])[1] || '').trim()
    const date = get('pubDate')
    return {
      title: get('title'),
      link: get('link'),
      image: (get('description').match(/src="([^"]+)"/) || [])[1] || '',
      date: date && !isNaN(new Date(date)) ? new Date(date).toISOString() : null,
    }
  })
}

// Pinterest now shows signed-out visitors long coded pin ids (e1_…) instead of numbers; both work in a /pin/ link
const pinIdOf = link => (link.match(/\/pin\/([\w-]{8,})\//) || [])[1] || null
// a short, stable save id for a long pin id
const saveIdOf = pinId => /^\d+$/.test(pinId) ? 'pin' + pinId : 'pin' + [...pinId].reduce((h, c) => (Math.imul(h, 31) + c.charCodeAt(0)) >>> 0, 7).toString(36) + [...pinId].reduce((h, c) => (Math.imul(h ^ c.charCodeAt(0), 16777619)) >>> 0, 2166136261).toString(36)

async function queuePins(fresh, to) {
  if (to) fresh = fresh.map(f => ({ ...f, to }))
  await updateQueue(queue => [...queue, ...fresh.filter(f => !queue.some(q => q.id === f.id && q.to === f.to))])
  await deliver()
  // a big board: let Dailies store what it has before reading more, so pictures and videos don't pile up here
  for (let i = 0; i < 60 && ports.size && (await getQueue()).length > 30; i++) await sleep(2000)
}

const pinPic = pin => { const im = pin.images || {}; return ((im['736x'] || im.orig || im['564x'] || im['474x'] || im['237x'] || im['236x'] || {}).url || '').replace(/\/(\d+x|237x|564x)\//, '/736x/') }
// the same pin has a coded id for signed-out visitors and a number for signed-in ones; its picture's name is the same either way
const pinKey = pin => (pinPic(pin).match(/\/([0-9a-f]{32})\.\w+$/) || [])[1] || pin.id

async function pinItem(pin, b, at) {
  const pic = pinPic(pin)
  const text = String(pin.title || pin.grid_title || pin.description || '').trim()
  const img = pic ? await fetchThumb(pic) : null
  const media = await mediaOfPin(pin)
  return { id: saveIdOf(pin.id), k: 'pin', bu: b.url, pk: picKeyOf(pic), u: `https://www.pinterest.com/pin/${pin.id}/`, t: text.split('\n')[0].slice(0, 200), c: text, g: [b.board.toLowerCase()], board: b.label, at, ...(img && { img }), ...media }
}

// which of these pins Dailies already has: it answers from its library, so their pictures aren't fetched again
// (no answer within 5 s, or no page: treat all as new, as before)
const haveWaiters = new Map()
function askHave(port, ids) {
  if (!port || !ids.length) return Promise.resolve([])
  const nonce = newId()
  return new Promise(res => {
    const t = setTimeout(() => { haveWaiters.delete(nonce); res([]) }, 5000)
    haveWaiters.set(nonce, have => { clearTimeout(t); res(have) })
    try { port.postMessage({ type: 'have', nonce, ids }) } catch { clearTimeout(t); haveWaiters.delete(nonce); res([]) }
  })
}
// what Dailies needs to show a pin before it is stored: its picture on Pinterest, its shape, its title
function previewOf(pin, at) {
  const im = pin.images || {}, x = im['736x'] || im.orig || im['564x'] || im['474x'] || {}
  return { id: saveIdOf(pin.id), pic: pinPic(pin), w: x.width || 0, h: x.height || 0, t: String(pin.title || pin.grid_title || pin.description || '').trim().split('\n')[0].slice(0, 140), at }
}
function sendPreview(mem, b, pins) {
  if (!mem.port || !pins.length) return
  try { mem.port.postMessage({ type: 'pin-preview', url: b.url, pins }) } catch { /* Dailies was closed */ }
}
async function readBoard(b, seen, mem, t0, progress) {
  const id = b.id || mem.pinIds[b.url] || (mem.pinIds[b.url] = await pinBoardId(b.user, b.board))
  if (!id) throw new Error('not-found')
  const again = !!(mem.fresh && mem.fresh.has(b.url)) // just followed: read it whole and hand over every pin, seen before or not
  const whole = again || !mem.pinDone[b.url]
  const base = Date.now()
  let bookmark = null, pos = 0, added = 0, count = 0
  do {
    const page = !bookmark && mem.first && mem.first[b.url] ? mem.first[b.url] : await boardPins({ ...b, id }, bookmark) // the first page may have been read already, up front
    if (mem.first) delete mem.first[b.url]
    if (again) sendPreview(mem, b, page.pins.filter(p => p && p.type === 'pin' && p.id).map((pin, i) => previewOf(pin, new Date(base - (pos + i) * 1000).toISOString())))
    let fresh = [], pageNew = 0
    // the new pins on this page are read six at a time (picture + is-it-a-GIF check), then handed over in the board's order
    const todo = []
    for (const pin of page.pins) {
      count++
      const at = new Date(base - pos++ * 1000).toISOString() // the board's order: its newest pin first
      if (!again && seen.has(pinKey(pin))) continue
      seen.add(pinKey(pin))
      todo.push([pin, at])
    }
    // pins Dailies already has (its memory outlives this extension's): counted as read, their pictures left alone
    if (todo.length) {
      const have = new Set(await askHave(mem.port, todo.map(([pin]) => saveIdOf(pin.id))))
      if (have.size) { const keep = todo.filter(([pin]) => !have.has(saveIdOf(pin.id))); added += todo.length - keep.length; todo.length = 0; todo.push(...keep); progress(added) }
    }
    const items = new Array(todo.length)
    let next = 0, handed = 0
    // handed over in the board's order as soon as the next ones are ready (four at a time), not after the whole page of fifty
    const handOver = async last => {
      const ready = []
      while (handed < todo.length && items[handed]) ready.push(items[handed++])
      fresh.push(...ready); pageNew += ready.length
      if (stopStamp > t0) return
      if (fresh.length && (last || fresh.length >= 4)) { const batch = fresh; fresh = []; await queuePins(batch, mem.K.to); added += batch.length; progress(added) }
    }
    await Promise.all([0, 1, 2, 3, 4, 5].map(async () => { while (next < todo.length && stopStamp <= t0) { const k = next++; items[k] = await pinItem(todo[k][0], b, todo[k][1]); if (again) items[k].again = true; await handOver(false) } })) // again: Dailies brings back even a copy that was deleted
    if (stopStamp > t0) return { added, count, stopped: true } // Stop: what wasn't handed over yet is dropped
    await handOver(true)
    await chrome.storage.local.set({ [mem.K.seen]: [...seen].slice(-20000) })
    bookmark = page.bookmark
    if (!whole && !pageNew) break
    if (bookmark) await sleep(rand(1200, 2500)) // a person scrolls; a script shouldn't hammer
    if (!ports.size || stopStamp > t0) return { added, count, stopped: true } // Dailies was closed, or you pressed Stop: carry on next time
    if (count >= PIN_CAP) break // a board this big is probably not all reference: the rest can be added on purpose
  } while (bookmark)
  // Pinterest stopped early (you're signed out): add what its widget shows, and read the whole board again next time
  // (not when we stopped ourselves at PIN_CAP: that board is done, and later looks only read its newest pages)
  if (b.count && count < b.count * .9 && count < PIN_CAP) {
    const fresh = []
    for (const pin of await widgetPins(b)) {
      if (seen.has(pinKey(pin))) continue
      fresh.push(await pinItem(pin, b, new Date(base - pos++ * 1000).toISOString()))
      seen.add(pinKey(pin))
    }
    if (fresh.length) { await queuePins(fresh, mem.K.to); added += fresh.length; progress(added) }
    await chrome.storage.local.set({ [mem.K.seen]: [...seen].slice(-20000) })
    return { added, count: Math.max(count, Math.min(b.count, 50)) }
  }
  mem.pinDone[b.url] = true
  return { added, count }
}

async function readProfileFeed(b, seen, mem) {
  const res = await fetch(`https://www.pinterest.com/${b.user}/feed.rss`, { credentials: 'omit' })
  if (!res.ok) throw new Error(res.status === 404 ? 'not-found' : `Pinterest answered ${res.status}`)
  const pins = parseFeed(await res.text())
  const fresh = []
  for (const pin of pins.reverse()) {
    const pinId = pinIdOf(pin.link)
    if (!pinId || seen.has(pinId)) continue
    const img = pin.image ? (await fetchThumb(pin.image.replace(/\/\d+x\//, '/736x/'))) || (await fetchThumb(pin.image)) : null
    const text = pin.title || ''
    const media = /^\d+$/.test(pinId) ? await pinMedia(pinId) : null
    fresh.push({ id: saveIdOf(pinId), k: 'pin', bu: b.url, pk: picKeyOf(pin.image && pin.image.replace(/\/\d+x\//, '/736x/')), u: `https://www.pinterest.com/pin/${pinId}/`, t: text.split('\n')[0].slice(0, 200), c: text, g: [], board: b.label, at: pin.date, ...(img && { img }), ...media })
    seen.add(pinId)
  }
  if (fresh.length) await queuePins(fresh, mem.K.to)
  await chrome.storage.local.set({ [mem.K.seen]: [...seen].slice(-20000) })
  return { added: fresh.length, count: pins.length }
}

const PIN_CAP = 1500 // pins read from one board in one go
const pinSyncing = new Set() // which Dailies ('web', 'claude') are being read right now
async function syncPinterest(force, port, fresh = new Set()) {
  const t0 = Date.now()
  const K = pinKeys(port)
  const got = await chrome.storage.local.get([K.boards, K.at, K.seen, K.done, 'pinIds'])
  const boards = got[K.boards] || [], pinSyncAt = got[K.at] || 0, seenPins = got[K.seen] || []
  const mem = { K, pinDone: got[K.done] || {}, pinIds: got.pinIds || {}, fresh, port }
  if (pinSyncing.has(K.to)) { if (force) { const a = pinAgain.get(K.to) || new Set(); for (const u of fresh) a.add(u); pinAgain.set(K.to, a) } return } // the running read picks these up afterwards
  if (!boards.length || (!force && Date.now() - pinSyncAt < 9.5 * 60e3)) return
  pinSyncing.add(K.to)
  const seen = new Set(seenPins)
  const status = {}
  const tell = (type, s) => { for (const p of ports) try { p.postMessage({ type, status: s }) } catch { /* closed */ } }
  try {
    // boards you just chose: the first page (up to fifty pins) of every one of them is read first, one quick request each, and
    // handed to Dailies to show at once; then each board is read and stored in full, starting from that same page
    mem.first = {}
    const chosen = boards.filter(b => b.board && fresh.has(b.url))
    for (const [i, b] of chosen.entries()) {
      if (stopStamp > t0) break
      try {
        const id = b.id || mem.pinIds[b.url] || (mem.pinIds[b.url] = await pinBoardId(b.user, b.board))
        if (!id) continue
        const page = await boardPins({ ...b, id }, null)
        mem.first[b.url] = page
        const base = Date.now()
        sendPreview(mem, b, page.pins.map((pin, k) => previewOf(pin, new Date(base - k * 1000).toISOString())))
      } catch { /* read again in the main pass */ }
      if (i < chosen.length - 1) await sleep(rand(250, 600))
    }
    for (const b of boards) {
      if (stopStamp > t0) break
      try {
        const r = b.board ? await readBoard(b, seen, mem, t0, added => tell('boards-progress', { [b.url]: { ok: true, busy: true, added } })) : await readProfileFeed(b, seen, mem)
        status[b.url] = { ok: true, count: r.count, added: r.added }
        if (r.stopped) { status[b.url].stopped = true; break }
      } catch (e) {
        const slow = /\b(429|403)\b/.test(String(e.message))
        status[b.url] = { ok: false, error: e.message === 'not-found' ? 'Board not found. Is it secret?' : slow ? 'Pinterest asked Dailies to slow down. It carries on by itself in about 10 minutes.' : String(e.message || e) }
        if (slow) break
      }
      await chrome.storage.local.set({ [K.done]: mem.pinDone, pinIds: mem.pinIds })
    }
    await chrome.storage.local.set({ [K.at]: Date.now() })
  } finally {
    pinSyncing.delete(K.to)
  }
  try { port.postMessage({ type: 'boards-status', status }) } catch { /* Dailies was closed */ }
  const again = pinAgain.get(K.to)
  if (again) { pinAgain.delete(K.to); syncPinterest(true, port, again) } // boards followed while this read was running
}

// ---- previews for references saved elsewhere (Slack, the phone): Dailies asks, we fetch ----
function readMeta(html) {
  const get = n => {
    const m = html.match(new RegExp(`<meta[^>]+(?:property|name)="${n}"[^>]+content="([^"]*)"`)) || html.match(new RegExp(`<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="${n}"`))
    return m ? decode(m[1]) : ''
  }
  return { title: get('og:title'), desc: get('og:description'), og: get('og:image'), ogUrl: get('og:url'), images: [] }
}

// ---- keeping your Instagram account safe ----
// Instagram watches for fast, steady, automatic traffic on a logged-in account. So: previews read one post page every 6-12 s
// (never in bursts), at most 150 a day; the first sign of "slow down" (a 429, a login or challenge page) pauses everything
// Instagram-related for 6 hours; and the Saved page is read by scrolling it, like a person, with random gaps.
const IG_PAUSE_MS = 6 * 3600e3, IG_DAILY = 80 // (was 150; Rohit, 26 Oct: Instagram is risky, keep their accounts safe)
const rand = (a, b) => a + Math.random() * (b - a)
async function igPausedUntil() { const { igPause = 0 } = await chrome.storage.local.get('igPause'); return igPause > Date.now() ? igPause : 0 }
async function igTrip() {
  const until = Date.now() + IG_PAUSE_MS
  await chrome.storage.local.set({ igPause: until })
  for (const p of ports) try { p.postMessage({ type: 'ig-pause', until }) } catch { /* closed */ }
  return until
}
// Every Instagram page we load waits its turn here, one after another (never two at once), 6–12 s apart.
// The last load's time is kept in session storage, so a restarted service worker still waits.
let igChain = Promise.resolve()
const igInLine = fn => { const p = igChain.then(fn, fn); igChain = p.catch(() => null); return p }
async function igSpace() {
  const { igLastPage = 0 } = await chrome.storage.session.get('igLastPage')
  const wait = igLastPage + rand(6000, 12000) - Date.now()
  if (wait > 0) await sleep(wait)
  await chrome.storage.session.set({ igLastPage: Date.now() })
}
// automatic loads (previews, the collection check) also count against today's share
function igGate() {
  return igInLine(async () => {
    if (await igPausedUntil()) return false
    const day = new Date().toISOString().slice(0, 10)
    const { igBudget = {} } = await chrome.storage.local.get('igBudget')
    const used = igBudget.day === day ? igBudget.n : 0
    if (used >= IG_DAILY) return false
    await chrome.storage.local.set({ igBudget: { day, n: used + 1 } })
    await igSpace()
    return true
  })
}
// tab work on Instagram (the collection check, finding your collections, Import): one at a time, spaced like the rest
let igTabChain = Promise.resolve()
const igTabTurn = fn => { const p = igTabChain.then(fn, fn); igTabChain = p.catch(() => null); return p }
const igStopSign = res => res.status === 429 || res.status === 403 || /instagram\.com\/(accounts\/login|challenge)/.test(res.url || '')

// the pictures after the first one in a carousel (X, Pinterest story pins, Instagram): sl marks "looked", more holds them
const slideBits = async urls => { const more = urls && urls.length ? await fetchMore(urls) : []; return { sl: 1, ...(more.length ? { more } : {}) } }
async function previewFor(item) {
  if (item.source === 'instagram' && item.ig) { // only the carousel's pictures, for a post you opened (one Instagram request, paced like every other)
    if (/\/(reel|reels|tv)\//.test(item.url)) return { sl: 1 }
    const code = (item.url.match(/\/p\/([\w-]+)/) || [])[1]
    if (!code || !(await igGate())) return null
    const r = await igSlideUrls(code)
    if (r.stop) { await igTrip(); return null }
    return await slideBits(r.urls)
  }
  if (item.source === 'twitter') {
    const media = await tweetVideo(item.url)
    const more = await slideBits(await tweetSlides(item.url))
    if (item.has) return { ...media, ...more } // Dailies already has the picture and only asked for the video
    const t = await tweetInfo(item.url)
    if (!t) return { ...media, ...more }
    return { ...media, ...more, t: t.title, a: t.author, c: t.caption, k: t.video ? 'video' : undefined, img: t.thumb ? await fetchThumb(t.thumb) : null }
  }
  if (item.source === 'youtube') {
    const id = youtubeId(item.url)
    const scrub = id ? await youtubeScrub(id) : null
    if (item.has) return scrub // Dailies already has the thumbnail and only asked for the preview frames
    const y = await youtubeInfo(item.url)
    const best = id ? await bestThumb({ images: [], url: item.url }, id) : null
    return { ...scrub, t: y?.title, a: y?.author, img: best?.img, ...(best && /oar/.test(best.src) ? { vthumb: 1 } : {}) }
  }
  if (item.source !== 'instagram' && item.source !== 'pinterest') return null
  const pinId = item.source === 'pinterest' && (item.url.match(/\/pin\/(\d+)/) || [])[1]
  const full = pinId ? await pinFull(pinId) : null
  const media = full ? { ...(full.media || {}), ...(full.pk ? { pk: full.pk } : {}), ...(item.peek ? {} : await slideBits(full.slideUrls)) } : null
  if (item.has && item.source !== 'instagram') return media // Dailies already has its picture and only asked whether it's a video
  // Instagram only shows preview tags to signed-in visitors, so this request carries your Instagram login.
  if (item.source === 'instagram' && !(await igGate())) return null // paused, or today's share is used up: it stays as it is and is asked again later
  // the address is rebuilt, never used as sent: Instagram only ever as /p/<code>/ (it carries your login), anything else only on a public https host
  let addr = null
  if (item.source === 'instagram') { const code = instagramCode(item.url); addr = code ? `https://www.instagram.com/p/${code}/` : null }
  else { try { const u = new URL(item.url); if (u.protocol === 'https:' && publicHost(u.hostname)) addr = u.href } catch { /* not an address */ } }
  if (!addr) return null
  const res = await fetch(addr, { credentials: item.source === 'instagram' ? 'include' : 'omit' })
  if (item.source === 'instagram' && igStopSign(res)) { await igTrip(); return null }
  if (!res.ok) return null
  const html = await res.text(), page = readMeta(html)
  // reels (and video posts): a sheet of frames to scrub through, when Dailies asked for one; photos answer 'none'
  // (a reel of 5 MB or less comes back whole too, so it plays in Dailies; the file is read from Instagram's video CDN, not instagram.com)
  const frames = item.source === 'instagram' && item.frames && VIDEO_PREVIEWS ? (igVideoUrl(html) ? (await videoFrames(igVideoUrl(html), true)) || {} : { scrub: 'none' }) : {}
  if (!page.og && !page.title) { // Instagram's page has no preview tags: its cover picture still works (the /media/ address)
    const cover = item.source === 'instagram' && !item.has ? await fetchThumb(instagramCover(item.url)) : null
    return cover || Object.keys(frames).length ? { ...frames, ...(cover ? { img: cover } : {}) } : null
  }
  const d = describe(page, item.source)
  if (item.has) return { ...frames, t: d.title, a: d.author, c: d.caption } // it has its picture already (a collection import, or only frames were asked for)
  const cover = item.source === 'instagram' ? await fetchThumb(instagramCover(item.url)) : null
  return { ...media, ...frames, t: d.title, a: d.author, c: d.caption, img: cover || (page.og ? await fetchThumb(page.og.replace(/\/(236x|474x|564x)\//, '/736x/')) : null) }
}

// a link to any other website: its first page's picture, title and description, within a few seconds
const within = (p, ms) => Promise.race([p, new Promise(r => setTimeout(() => r(null), ms))])
// A site behind a bot check (Dribbble, Behance, Pexels, EyeCandy…) turns away the quick read above. Then the page is opened
// once in a background tab you don't switch to (like Instagram collections are), its preview tags are read, and the tab closes.
// One at a time, public https sites only, 15 s at most, and each address only ever once.
const BOT_WALL = /just a moment|attention required|checking your browser|access denied|verify you are human/i
let tabLock = Promise.resolve()
const tabKey = url => { try { return new URL(url).href } catch { return String(url) } } // 'https://x.com' and 'https://x.com/' are the same address
async function tabTried(url) { const { tabPeeked = [] } = await chrome.storage.local.get('tabPeeked'); return tabPeeked.includes(tabKey(url)) }
async function markTabTried(url) { const { tabPeeked = [] } = await chrome.storage.local.get('tabPeeked'); await chrome.storage.local.set({ tabPeeked: [...tabPeeked.filter(u => u !== url), url].slice(-400) }) }
const tabOk = href => { try { const u = new URL(href); return u.protocol === 'https:' && publicHost(u.hostname) && !/(^|\.)instagram\.com$/i.test(u.hostname) } catch { return false } }
function tabPage(url, ms = 15000) {
  const run = async () => {
    let u; try { u = new URL(url) } catch { return null }
    if (!(await canFetch('https://*/*'))) return null // reading other websites is allowed in the popup (Allow on all websites)
    if (!tabOk(u.href) || await tabTried(u.href)) return null // checked again inside the queue: two rounds never open the same address
    await markTabTried(u.href)
    let tab = null, gone = false
    // if the page sends the tab anywhere but a public https site (or to Instagram), it is closed at once
    const watch = (id, info) => { if (tab && id === tab.id && info.url && !tabOk(info.url)) { gone = true; chrome.tabs.remove(id).catch(() => {}) } }
    chrome.tabs.onUpdated.addListener(watch)
    const hardStop = setTimeout(() => { gone = true; if (tab) chrome.tabs.remove(tab.id).catch(() => {}) }, ms + 2000) // whatever the page does (alerts, hangs), it closes
    try {
      tab = await chrome.tabs.create({ url: u.href, active: false })
      const t0 = Date.now()
      while (Date.now() - t0 < ms && !gone) {
        await sleep(800)
        let v = null
        try {
          const [r] = await within(chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
            const m = n => (document.querySelector(`meta[property="${n}"]`) || document.querySelector(`meta[name="${n}"]`))?.content || ''
            return { title: m('og:title') || m('twitter:title') || document.title, desc: m('og:description') || m('twitter:description') || m('description'), site: m('og:site_name'), image: m('og:image:secure_url') || m('og:image') || m('twitter:image') || m('twitter:image:src'), href: location.href, ready: document.readyState }
          } }), 2500) || [] // a page stuck on an alert can't hold this up
          v = r && r.result
        } catch { continue } // still on the bot check, or between pages
        if (!v || BOT_WALL.test(v.title || '')) continue
        let end; try { end = new URL(v.href) } catch { return null }
        if (end.protocol !== 'https:' || !publicHost(end.hostname)) return null
        let image = ''; try { image = v.image ? new URL(v.image, end.href).href : '' } catch { /* no picture */ }
        // a blank bot-check page that reloads itself is not the answer: wait for a picture or a real title
        if (image || (v.ready === 'complete' && v.title && Date.now() - t0 > 5000)) return { title: String(v.title || '').slice(0, 300), desc: String(v.desc || '').slice(0, 600), site: String(v.site || '').slice(0, 100), image: /^https:/.test(image) ? image : '', icon: '' }
      }
      return null
    } catch { return null } finally { clearTimeout(hardStop); chrome.tabs.onUpdated.removeListener(watch); if (tab) chrome.tabs.remove(tab.id).catch(() => {}) }
  }
  const timed = () => Promise.race([run(), sleep(ms + 4000).then(() => null)]) // the queue never waits longer than this
  const p = tabLock.then(timed, timed)
  tabLock = p.catch(() => null)
  return p
}
async function sitePreview(item, allowTab = false) {
  let page = await sitePage(item.url, 6000)
  if ((!page || BOT_WALL.test(page.title || '') || !(page.title || page.image || page.desc)) && allowTab && !(await tabTried(item.url))) page = (await tabPage(item.url)) || page
  if (page && BOT_WALL.test(page.title || '')) page = { ...page, title: '', desc: '' }
  const u = new URL(item.url), host = u.hostname.replace(/^www\./, '')
  let img = null
  // the page's own picture first, then its app icon; a site that turns visitors away (a bot check) still gets its icon
  for (const src of [page && page.image, page && page.icon, !(page && (page.image || page.icon)) && `${u.origin}/apple-touch-icon.png`, !(page && (page.image || page.icon)) && `${u.origin}/favicon.ico`]) {
    if (!img && src) img = await within(fetchThumb(src), 4000)
  }
  if (!img && !(page && (page.title || page.desc))) return null
  return { t: (page && page.title) || host, a: (page && page.site) || host, c: page ? page.desc : '', img }
}

const APP_SOURCES = ['instagram', 'pinterest', 'twitter', 'youtube']
// ---- search from Dailies: the whole web (pictures), Pinterest, YouTube. Dailies sends only the words and which place to look in.
const found = new Map() // result id → { full, url } for the last searches, so a picture is only fetched in full if you save it
const saveFound = () => chrome.storage.session.set({ found: [...found] }).catch(() => {}) // kept across worker restarts (the user may look at results for minutes)
const loadFound = async () => { if (found.size) return; try { for (const [k, v] of ((await chrome.storage.session.get('found')).found || [])) found.set(k, v) } catch { /* none */ } }
async function onSearch(msg, port) {
  const q = String(msg.q || '').replace(/\s+/g, ' ').trim().slice(0, 200), scope = ['web', 'pinterest', 'youtube'].includes(msg.scope) ? msg.scope : null
  const nonce = String(msg.nonce || '').slice(0, 40)
  const reply = body => { try { port.postMessage({ type: 'searched', nonce, scope, ...body }) } catch { /* closed */ } }
  if (!q || !scope) return reply({ results: [], next: null })
  let r = { results: [], next: null }
  try { r = await runSearch(scope, q, scope === 'pinterest' ? (typeof msg.page === 'string' ? msg.page.slice(0, 600) : null) : (Number.isInteger(msg.page) ? Math.min(msg.page, 6) : 0)) } catch { /* nothing found */ }
  // the previews, six at a time, so the page can show them at once
  const out = r.results.slice(0, 40), thumbs = new Array(out.length)
  let i = 0
  await Promise.all([0, 1, 2, 3, 4, 5].map(async () => { while (i < out.length) { const k = i++; thumbs[k] = await within(fetchThumb(out[k].thumb, 520, 0.72), 6000) } }))
  const results = []
  out.forEach((x, k) => {
    if (!thumbs[k]) return
    found.set(x.id, { full: x.full || null, url: x.url })
    results.push({ id: x.id, title: x.title, sub: x.sub, url: x.url, thumb: thumbs[k] })
  })
  if (found.size > 400) for (const key of [...found.keys()].slice(0, found.size - 300)) found.delete(key)
  saveFound()
  reply({ results, next: r.next })
}
// saving a picture from the web: fetch the large version (the previews are small)
async function onPickImage(msg, port) {
  await loadFound()
  const f = found.get(String(msg.id || ''))
  let img = null
  if (f && f.full) img = await within(fetchThumb(f.full, 1280, 0.85), 9000)
  try { port.postMessage({ type: 'pickedimage', id: String(msg.id || ''), img }) } catch { /* closed */ }
}
// the Save box asks for a link's picture and title the moment it is pasted, before anything is saved
async function onPeek(msg, port) {
  const url = String(msg.url || '').slice(0, 2000), source = sourceOf(url)
  let result = null
  if (/^https:\/\//.test(url)) {
    try {
      if (source === 'twitter') {
        const t = await tweetInfo(url)
        result = t ? { t: t.title, a: t.author, c: t.caption, img: t.thumb ? await fetchThumb(t.thumb) : null } : null
      } else if (source === 'youtube') {
        const id = youtubeId(url), y = await youtubeInfo(url), best = id ? await bestThumb({ images: [], url }, id) : null
        result = { t: y?.title, a: y?.author, img: best?.img }
      } else if (source === 'instagram' || source === 'pinterest') {
        if (source === 'instagram') { const until = await igPausedUntil(); if (until) { try { port.postMessage({ type: 'peeked', nonce: String(msg.nonce || '').slice(0, 40), url, result: { paused: until } }) } catch { /* closed */ } return } }
        result = await previewFor({ url, source, has: false, frames: false, peek: true })
      } else {
        result = await sitePreview({ url, source }, true) // you just pasted it: worth a background tab if the site has a bot check
      }
    } catch { /* no preview: it is saved as it is and filled in afterwards */ }
  }
  try { port.postMessage({ type: 'peeked', nonce: String(msg.nonce || '').slice(0, 40), url, result: result ? { t: result.t, a: result.a, c: result.c, img: result.img, pk: result.pk } : source === 'instagram' ? { failed: true } : null }) } catch { /* closed */ }
}
async function enrichAll(items, port) {
  const list = (Array.isArray(items) ? items : []).slice(0, 50).filter(item => item && typeof item.url === 'string' && /^https:\/\//.test(item.url) && sourceOf(item.url) === item.source) // only a platform's own addresses, or a plain website's
  const send = item => result => { try { port.postMessage({ type: 'enriched', result: { id: item.id, ...(result || {}) } }); return true } catch { return false } }
  // websites go four at a time and straight away, so a thumbnail shows up in a few seconds; the apps keep their slow, careful pace
  const sites = list.filter(i => !APP_SOURCES.includes(i.source)).slice(0, 16)
  const apps = list.filter(i => APP_SOURCES.includes(i.source))
  const tabsLeft = 0 // no background tabs here: a link that arrived by itself (Slack, an import) never opens with your logins; only one you paste does (onPeek)
  const siteWorker = async () => {
    while (sites.length) {
      const item = sites.shift()
      let result = null
      try { result = await sitePreview(item, tabsLeft > 0) } catch { /* it stays as it is */ }
      if (!send(item)(result)) return
    }
  }
  const appWorker = async () => {
    for (const item of apps) {
      let result = null
      try { result = await previewFor(item) } catch { /* leave it for Claude's preview refresh */ }
      if (!send(item)(result)) return
      await new Promise(r => setTimeout(r, 400))
    }
  }
  await Promise.all([siteWorker(), siteWorker(), siteWorker(), siteWorker(), appWorker()])
}

// ---- Instagram: your saved collections, read off the collection page itself (ig.js) ----
// "Import" in the popup scrolls the whole collection; opening a collection you follow picks up the newest saves on screen.
// While Dailies is open we also look at each collection you follow ourselves: in a background tab, so Dailies stays in
// front, one collection at a time, closing each tab as soon as its newest saves are read (or after 30 s if it hangs).
async function onIgCollections(cols, force) {
  await chrome.storage.local.set({ igCols: cols })
  syncInstagram(force)
}

// Your collections are looked at only when you open or reload Dailies, or press Refresh (Rohit, 27 Oct: never on a timer while
// it sits open): two collections each time, taking turns, and not more than once every 10 minutes however often you reload
const IG_PER_CHECK = 2, IG_LOOK_GAP = 10 * 60e3, IG_TIMEOUT = 30e3
const sleep = ms => new Promise(r => setTimeout(r, ms))
const igAuto = new Map() // tabs we opened ourselves → called once ig.js says it has read the page
let igSyncing = false
async function syncInstagram(asked) {
  const { igCols = [], igSyncAt = 0, igRot = 0 } = await chrome.storage.local.get(['igCols', 'igSyncAt', 'igRot'])
  const now = Date.now()
  if (!asked || igSyncing || !igCols.length || !ports.size || await igPausedUntil()) return
  if (now - igSyncAt < IG_LOOK_GAP) return
  igSyncing = true
  await chrome.storage.local.set({ igSyncAt: now })
  const n = Math.min(IG_PER_CHECK, igCols.length)
  try {
    for (let i = 0; i < n; i++) {
      const col = igCols[(igRot + i) % igCols.length]
      if (!ports.size) break // Dailies was closed: don't open any more tabs
      if (!(await igGate())) break // Instagram asked for a check (or today's share is used up): stop at once, no more tabs
      await igTabTurn(() => checkIgCollection(col))
    }
  } finally {
    await chrome.storage.local.set({ igRot: (igRot + n) % Math.max(1, igCols.length) })
    igSyncing = false
  }
}

async function checkIgCollection(col) {
  let tabId = null, result
  try {
    const tab = await chrome.tabs.create({ url: col.url, active: false })
    tabId = tab.id
    await igTabs(ids => [...ids, tabId])
    chrome.tabs.update(tabId, { muted: true }).catch(() => {})
    result = await Promise.race([scanIgTab(tabId), sleep(IG_TIMEOUT).then(() => 'timeout')])
  } catch (e) {
    result = String(e && e.message || e)
  } finally {
    if (tabId != null) {
      igAuto.delete(tabId)
      await chrome.tabs.remove(tabId).catch(() => {}) // already closed by hand: fine
      await igTabs(ids => ids.filter(id => id !== tabId))
    }
  }
  if (result === 'done') return
  delete igRuns[col.url]
  const error = result === 'signed-out' ? 'Sign in to Instagram in Chrome, then press Refresh in Dailies'
    : result === 'timeout' ? 'Instagram took too long to load. Dailies will try again in 30 minutes'
    : result
  await reportIg({ [col.url]: { ok: false, error, at: new Date().toISOString() } })
}

// 'done' once ig.js has read the collection, 'signed-out' if Instagram sent us to its login page
async function scanIgTab(tabId) {
  const finished = new Promise(resolve => igAuto.set(tabId, () => resolve('done')))
  const ask = () => chrome.tabs.sendMessage(tabId, { type: 'ig-scan', full: false, wait: true }).catch(() => null)
  await tabLoaded(tabId)
  for (let i = 0; i < 30; i++) { // the 30 s limit in checkIgCollection ends this first if nothing works
    let reply = await ask()
    if (!reply) { // Chrome can hold back ig.js in a tab that was never shown: add it ourselves (it runs only once per page)
      await chrome.scripting.executeScript({ target: { tabId }, files: ['ig.js'] }).catch(() => {})
      reply = await ask()
    }
    if (reply && reply.ok) return finished
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    if (!tab) return 'The Instagram tab was closed before it was read'
    if (/instagram\.com\/challenge/.test(tab.url || '')) { await igTrip(); return 'Instagram asked for a check. Dailies will leave Instagram alone for a few hours.' }
    if (/instagram\.com\/accounts\/login/.test(tab.url || '')) return 'signed-out'
    await sleep(1000)
  }
  return 'Couldn’t read the collection page'
}

function tabLoaded(tabId) {
  return new Promise(resolve => {
    const done = () => { chrome.tabs.onUpdated.removeListener(on); resolve() }
    const on = (id, info) => { if (id === tabId && info.status === 'complete') done() }
    chrome.tabs.onUpdated.addListener(on)
    chrome.tabs.get(tabId).then(t => { if (t.status === 'complete') done() }, done)
    setTimeout(done, IG_TIMEOUT) // never leave the listener behind
  })
}

// the tabs we opened, kept outside this worker: if Chrome stops it halfway through, the next start closes them
async function igTabs(change) {
  const { igTabs: ids = [] } = await chrome.storage.session.get('igTabs')
  await chrome.storage.session.set({ igTabs: change(ids) })
}
chrome.storage.session.get('igTabs').then(async ({ igTabs: ids = [] }) => {
  if (!ids.length) return
  for (const id of ids) await chrome.tabs.remove(id).catch(() => {})
  await chrome.storage.session.set({ igTabs: [] })
})

async function reportIg(status) {
  const { igStatus = {} } = await chrome.storage.local.get('igStatus')
  await chrome.storage.local.set({ igStatus: { ...igStatus, ...status } })
  for (const port of ports) try { port.postMessage({ type: 'ig-status', status }) } catch { /* closed */ }
}

// following a collection (from the popup) waits here until Dailies is open to add it to your settings
async function followIg(col) {
  if (!col || !col.url) return
  const { igFollow = [], igCols = [] } = await chrome.storage.local.get(['igFollow', 'igCols'])
  if (igCols.some(c => c.url === col.url)) return
  if (!igFollow.some(c => c.url === col.url)) igFollow.push(col)
  await chrome.storage.local.set({ igFollow, igCols: [...igCols, col] })
  await sendIgFollows()
}
async function sendIgFollows() {
  const { igFollow = [] } = await chrome.storage.local.get('igFollow')
  const port = [...ports][0]
  if (!igFollow.length || !port) return
  try { port.postMessage({ type: 'ig-follow', cols: igFollow }); await chrome.storage.local.set({ igFollow: [] }) } catch { /* next time */ }
}

// Import, a little at a time (Rohit, 27 Oct: "the user still feels all their collections are here", with less risk):
// the first Import of a collection brings its newest 150 saves quickly; Import again (6 hours or more later) reads the rest at
// the pace of someone looking through their saves, at most IG_DAY_ROUNDS scrolls a day, carrying on another day if needed.
// Getting to older saves always means scrolling past the newer ones, so one slow pass beats many small ones.
const IG_FIRST = 150, IG_DAY_ROUNDS = 250, IG_REST_GAP = 6 * 3600e3, IG_SLOW_AFTER = 20
const igToday = () => new Date().toISOString().slice(0, 10)
async function igScanPlan(url) {
  const { igImp = {}, igRounds = {} } = await chrome.storage.local.get(['igImp', 'igRounds'])
  const st = igImp[url], left = IG_DAY_ROUNDS - (igRounds.day === igToday() ? igRounds.used || 0 : 0)
  if (left < 10) return { error: 'That’s today’s share of reading Instagram. Run Import again tomorrow to carry on.' }
  if (!st || st.end) return { limit: IG_FIRST, rounds: Math.min(left, 60), slowAfter: 400 } // first time (or all in already): the newest saves
  const wait = st.at + IG_REST_GAP - Date.now()
  if (wait > 0) return { error: `The newest saves are in. The rest can be read from ${new Date(st.at + IG_REST_GAP).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}, slowly, so Instagram stays happy.` }
  return { limit: 3000, rounds: left, slowAfter: IG_SLOW_AFTER }
}
async function igScanDone(url, msg) {
  const { igImp = {}, igRounds = {} } = await chrome.storage.local.get(['igImp', 'igRounds'])
  const prev = igImp[url] || {}
  // a collection that was all in stays all in after a quick look at its newest saves
  igImp[url] = { depth: Math.max(prev.depth || 0, msg.total || 0), end: !!msg.end || (!!prev.end && (msg.total || 0) <= IG_FIRST), at: Date.now() }
  const day = igToday(), used = (igRounds.day === day ? igRounds.used || 0 : 0) + (+msg.rounds || 0)
  await chrome.storage.local.set({ igImp, igRounds: { day, used } })
  return igImp[url]
}

async function startIgImport(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null)
  const plan = await igScanPlan(tab && parseIgCollection(tab.url || '') ? parseIgCollection(tab.url).url : '')
  if (plan.error) throw new Error(plan.error)
  const ask = () => chrome.tabs.sendMessage(tabId, { type: 'ig-scan', full: true, limit: plan.limit, rounds: plan.rounds, slowAfter: plan.slowAfter })
  try { await ask() } catch { // a tab opened before the extension was updated: add the reader now
    await chrome.scripting.executeScript({ target: { tabId }, files: ['ig.js'] })
    await ask()
  }
}

const igRuns = {} // per collection page: when it started and how many were new
async function onIgLinks(msg, tab) {
  const col = parseIgCollection(msg.url)
  if (!col) return
  const run = igRuns[col.url] ||= { base: Date.now(), added: 0, total: 0 }
  const { seenIg = [] } = await chrome.storage.local.get('seenIg')
  const seen = new Set(seenIg)
  const fresh = []
  const items = msg.items || []
  for (let i = 0; i < items.length; i++) {
    const t = items[i]
    const pos = (msg.total || 0) - items.length + i // place in the collection: newest save first
    if (seen.has(t.code) && !msg.full) continue // a quick look skips what it sent before; Import sends everything again (Dailies drops what it already has)
    seen.add(t.code)
    fresh.push({
      id: 'ig' + t.code, k: 'igsave', u: `https://www.instagram.com/${t.reel ? 'reel' : 'p'}/${t.code}/`,
      t: '', a: t.author ? '@' + t.author.replace(/^@/, '') : '', g: col.id ? [col.slug] : [], board: col.label,
      at: new Date(run.base - pos * 1000).toISOString(), img: t.img ? await fetchThumb(t.img) : null,
    })
  }
  run.added += fresh.length
  run.total = msg.total || run.total
  if (fresh.length) {
    await updateQueue(queue => [...queue, ...fresh.filter(f => !queue.some(q => q.id === f.id))])
    await chrome.storage.local.set({ seenIg: [...seen].slice(-20000) })
    await deliver()
    await showPending()
  }
  const st = msg.done && msg.full ? await igScanDone(col.url, msg) : null
  const more = !!(st && !st.end && !msg.blocked) // the newest are in; Import again reads the rest
  chrome.runtime.sendMessage({ type: 'ig-progress', url: col.url, total: run.total, added: run.added, done: !!msg.done, more }).catch(() => {})
  for (const p of ports) try { p.postMessage({ type: 'ig-progress', url: col.url, total: run.total, added: run.added, done: !!msg.done, blocked: !!msg.blocked, more }) } catch { /* closed */ }
  if (msg.blocked) await igTrip()
  if (msg.done) {
    const { igStatus = {} } = await chrome.storage.local.get('igStatus')
    const prev = igStatus[col.url] || {}
    // a quick look only sees the top rows: the collection's count is what the last full import found plus anything new
    const status = { [col.url]: { ok: true, added: run.added, total: Math.max(run.total, (prev.total || 0) + run.added), at: new Date().toISOString() } }
    delete igRuns[col.url]
    await reportIg(status)
    if (tab && igAuto.has(tab.id)) igAuto.get(tab.id)() // one of our background tabs: it can close now
  }
}

async function onIgVisit(url, tab) {
  if (tab && igAuto.has(tab.id)) return // our own background tab: it's already being read
  const col = parseIgCollection(url)
  const { igCols = [] } = await chrome.storage.local.get('igCols')
  if (col && tab && igCols.some(c => c.url === col.url)) chrome.tabs.sendMessage(tab.id, { type: 'ig-scan', full: false }).catch(() => {})
}


// ---- "Import → Instagram": find the collections, then read the ones you pick ----
const IG_FULL_TIMEOUT = 45 * 60e3 // the slow pass over a big collection takes a while
async function igUserOf(tabId) {
  for (let i = 0; i < 14; i++) {
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    if (!tab) return null
    if (/instagram\.com\/accounts\/login/.test(tab.url || '')) return 'signed-out'
    const r = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const a = [...document.querySelectorAll('a[href]')].find(a => /^\/[\w.]+\/$/.test(a.getAttribute('href')) && a.querySelector('img[alt*="profile picture" i]'))
      return a ? a.getAttribute('href').replace(/\//g, '') : null
    } }).then(x => x[0] && x[0].result, () => null)
    if (r) return r
    await sleep(1000)
  }
  return null
}

function onIgList(msg, port) { return igTabTurn(() => igListNow(msg, port)) }
async function igListNow(msg, port) {
  const reply = r => { try { port.postMessage({ type: 'iglist', nonce: msg.nonce, ...r }) } catch { /* closed */ } }
  const until = await igPausedUntil()
  if (until) return reply({ error: 'paused', until })
  await igInLine(igSpace)
  let tabId = null
  try {
    const tab = await chrome.tabs.create({ url: 'https://www.instagram.com/', active: false })
    tabId = tab.id
    await igTabs(ids => [...ids, tabId])
    await tabLoaded(tabId)
    const user = await igUserOf(tabId)
    if (user === 'signed-out' || !user) return reply({ error: user ? 'signed-out' : 'no-user' })
    await chrome.tabs.update(tabId, { url: `https://www.instagram.com/${user}/saved/` })
    await sleep(1500); await tabLoaded(tabId)
    let found = []
    for (let i = 0; i < 15 && !found.length; i++) {
      found = await chrome.scripting.executeScript({ target: { tabId }, func: user => {
        const out = []
        for (const a of document.querySelectorAll('main a[href*="/saved/"]')) {
          const m = a.getAttribute('href').match(/^\/([\w.]+)\/saved\/([^/]+)\/(\d+)?\/?$/)
          if (!m || m[1] !== user || m[2] === 'audio') continue
          out.push({ slug: m[2], id: m[3] || null, name: (a.innerText || '').trim().split('\n')[0], pics: [...a.querySelectorAll('img')].map(i => i.currentSrc || i.src).filter(Boolean).slice(0, 3) })
        }
        return out
      }, args: [user] }).then(x => (x[0] && x[0].result) || [], () => [])
      if (!found.length) await sleep(1000)
    }
    const seen = new Set(), cols = []
    for (const f of found) {
      const col = parseIgCollection(f.id ? `https://www.instagram.com/${user}/saved/${f.slug}/${f.id}/` : `https://www.instagram.com/${user}/saved/all-posts/`)
      if (!col || seen.has(col.url)) continue
      seen.add(col.url)
      cols.push({ ...col, name: f.id ? (f.name || col.label) : 'All posts', pics: (await Promise.all(f.pics.map(smallPic))).filter(Boolean) })
    }
    if (!cols.length) return reply({ error: 'none' })
    cols.sort((a, b) => (b.id ? 0 : 1) - (a.id ? 0 : 1))
    reply({ user, cols })
  } catch (e) {
    reply({ error: String(e && e.message || e) })
  } finally {
    if (tabId != null) { await chrome.tabs.remove(tabId).catch(() => {}); await igTabs(ids => ids.filter(id => id !== tabId)) }
  }
}

// each picked collection is scrolled once from top to bottom in a tab you can see (Instagram only loads more of a page that's on screen)
let igImportTab = null, igImporting = false
async function onIgImport(msg, port) {
  if (igImporting) { try { port.postMessage({ type: 'ig-import', error: 'An import is already running.' }) } catch { /* closed */ } return }
  igImporting = true
  try { await igImportNow(msg, port) } finally { igImporting = false }
}
async function igImportNow(msg, port) {
  const t0 = Date.now()
  const from = port.sender && port.sender.tab
  const say = m => { try { port.postMessage({ type: 'ig-import', ...m }) } catch { /* closed */ } }
  for (const col of msg.cols || []) {
    if (stopStamp > t0) break
    const until = await igPausedUntil()
    if (until) { say({ url: col.url, error: 'paused', until }); break }
    await followIg(col)
    const plan = await igScanPlan(col.url)
    if (plan.error) { say({ url: col.url, error: plan.error }); continue }
    let tabId = null, result
    await igTabTurn(async () => { // wait for any other Instagram tab work, then space this page like the rest
    if (await igPausedUntil()) { result = 'paused'; return }
    await igInLine(igSpace)
    try {
      const tab = await chrome.tabs.create({ url: col.url, active: true })
      tabId = tab.id
      igImportTab = tabId
      await igTabs(ids => [...ids, tabId])
      result = await Promise.race([scanIgFull(tabId, plan), sleep(IG_FULL_TIMEOUT).then(() => 'Instagram took too long. Run Import again to carry on.')])
    } catch (e) { result = String(e && e.message || e) }
    finally {
      igImportTab = null
      if (tabId != null) {
        igAuto.delete(tabId)
        await chrome.tabs.remove(tabId).catch(() => {})
        await igTabs(ids => ids.filter(id => id !== tabId))
      }
      if (from) { chrome.tabs.update(from.id, { active: true }).catch(() => {}); chrome.windows.update(from.windowId, { focused: true }).catch(() => {}) }
    }
    })
    if (result === 'paused') { const until = await igPausedUntil(); say({ url: col.url, error: 'paused', until }); break }
    if (stopStamp > t0) { delete igRuns[col.url]; say({ url: col.url, error: 'Stopped.' }); break }
    if (result !== 'done') { delete igRuns[col.url]; say({ url: col.url, error: result === 'signed-out' ? 'Sign in to Instagram in Chrome, then run Import again.' : result }); if (await igPausedUntil()) break }
  }
  say({ finished: true })
}

async function scanIgFull(tabId, plan) {
  const finished = new Promise(resolve => igAuto.set(tabId, () => resolve('done')))
  const ask = () => chrome.tabs.sendMessage(tabId, { type: 'ig-scan', full: true, wait: true, limit: plan.limit, rounds: plan.rounds, slowAfter: plan.slowAfter }).catch(() => null)
  await tabLoaded(tabId)
  for (let i = 0; i < 30; i++) {
    let reply = await ask()
    if (!reply) { await chrome.scripting.executeScript({ target: { tabId }, files: ['ig.js'] }).catch(() => {}); reply = await ask() }
    if (reply && reply.ok) return finished
    const tab = await chrome.tabs.get(tabId).catch(() => null)
    if (!tab) return 'The Instagram tab was closed before it finished. Run Import again to carry on.'
    if (/instagram\.com\/challenge/.test(tab.url || '')) { await igTrip(); return 'Instagram asked for a check. Dailies will leave Instagram alone for a few hours.' }
    if (/instagram\.com\/accounts\/login/.test(tab.url || '')) return 'signed-out'
    await sleep(1000)
  }
  return 'Couldn’t read the collection page'
}
