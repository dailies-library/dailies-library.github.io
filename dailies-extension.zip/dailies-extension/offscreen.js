// A hidden page the background script opens when it needs a <video>: it reads a saved video (an Instagram reel, or an X /
// Pinterest video too big to keep) and lays 40 evenly spaced frames out on one JPEG, 8 across, so Dailies can flip through
// them on hover (and play them on a phone). A video of 5 MB or less is handed back whole as well, when asked.
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || msg.target !== 'offscreen' || msg.type !== 'video-frames') return
  framesOf(msg.url, msg.keep || 0).then(reply, err => reply({ error: String(err && err.message || err) }))
  return true // the reply comes later
})

const once = (el, ev, ms = 8000) => new Promise((res, rej) => {
  const t = setTimeout(() => { el.removeEventListener(ev, ok); rej(new Error(ev + ' timed out')) }, ms)
  const ok = () => { clearTimeout(t); res() }
  el.addEventListener(ev, ok, { once: true })
})

async function framesOf(url, keep) {
  const res = await fetch(url, { credentials: 'omit' })
  if (!res.ok) throw new Error('video ' + res.status)
  const blob = await res.blob()
  if (blob.size > 60e6) throw new Error('video too big')
  const src = URL.createObjectURL(blob)
  const v = Object.assign(document.createElement('video'), { muted: true, playsInline: true, preload: 'auto', src })
  try {
    await once(v, 'loadedmetadata')
    const dur = v.duration
    if (!(dur > 0.5) || !v.videoWidth) throw new Error('not a video')
    // 720p frames (the short side up to 720, never more than the video has), 24 of them, so hover previews look sharp
    const n = dur >= 4 ? 24 : Math.max(8, Math.floor(dur * 6)), cols = 8
    const vw = v.videoWidth, vh = v.videoHeight, short = Math.min(720, vw, vh)
    let fw, fh
    if (vw >= vh) { fh = Math.round(short / 2) * 2; fw = Math.max(2, Math.round(fh * vw / vh / 2) * 2) }
    else { fw = Math.round(short / 2) * 2; fh = Math.max(2, Math.round(fw * vh / vw / 2) * 2) }
    if (fh === 240) fh = 242 // 240 tall marks the old low-res sheets, which Dailies asks to redo
    const c = Object.assign(document.createElement('canvas'), { width: cols * fw, height: Math.ceil(n / cols) * fh })
    const g = c.getContext('2d')
    for (let k = 0; k < n; k++) {
      v.currentTime = Math.min(dur - 0.05, (k + 0.5) * dur / n)
      await once(v, 'seeked')
      g.drawImage(v, (k % cols) * fw, Math.floor(k / cols) * fh, fw, fh)
    }
    const jpg = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.8))
    const b64 = await new Promise(r => { const f = new FileReader(); f.onload = () => r(String(f.result).split(',')[1]); f.readAsDataURL(jpg) })
    const out = { scrub: b64, sn: n, sc: cols, sw: fw, sh: fh }
    // a small video (keep = the limit in bytes) comes back whole too, so it can play in Dailies
    if (keep && blob.size <= keep) {
      const vid = await new Promise(r => { const f = new FileReader(); f.onload = () => r(String(f.result).split(',')[1]); f.readAsDataURL(blob) })
      Object.assign(out, { media: 'video', vid: vid.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''), vw: v.videoWidth, vh: v.videoHeight, dur: Math.round(dur * 10) / 10 })
    }
    return out
  } finally { URL.revokeObjectURL(src); v.removeAttribute('src') }
}
