// Runs inside Claude artifact frames. It only wakes up on the Dailies page, which marks itself with
// data-dailies-inbox="ready"; then it passes saves from the extension to the page and the results back.
(() => {
  if (window.__dailiesBridge) return // already running in this page (the extension re-adds it to open pages after an update)
  window.__dailiesBridge = true
  let port = null, dead = false
  const MY = (() => { try { return chrome.runtime.getManifest().version } catch { return '?' } })()
  document.documentElement.dataset.dailiesBridge = MY // the newest copy marks the page; an older copy then stays quiet
  // the extension was reloaded or updated while this page was open: this copy can't reach it any more. It tells Dailies once
  // (so nothing waits for answers that never come) and goes quiet; the new copy the extension adds says hello again.
  const gone = () => {
    if (dead) return
    dead = true; port = null
    window.removeEventListener('message', onMessage)
    if (document.documentElement.dataset.dailiesBridge === MY) window.postMessage({ type: 'dailies:ext-gone' }, '*') // unless a newer copy has already said hello
  }
  // what Dailies asks the extension for; only these (re)open the link
  const ASKS = new Set(['dailies:result', 'dailies:boards', 'dailies:igcols', 'dailies:vocab', 'dailies:stop', 'dailies:iglist', 'dailies:igimport',
    'dailies:ytlist', 'dailies:pinuser', 'dailies:enrich', 'dailies:search', 'dailies:pickimage', 'dailies:peek'])
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id) } catch { return false } }
  const connect = () => {
    if (dead || port || document.documentElement.dataset.dailiesInbox !== 'ready') return
    if (!alive()) return gone()
    try { port = chrome.runtime.connect({ name: 'dailies' }) } catch { return gone() }
    port.onMessage.addListener(msg => {
      if (msg && msg.type === 'items') for (const item of msg.items) window.postMessage({ type: 'dailies:save', item }, '*')
      if (msg && msg.type === 'boards-status') window.postMessage({ type: 'dailies:boards-status', status: msg.status }, '*')
      if (msg && msg.type === 'boards-progress') window.postMessage({ type: 'dailies:boards-progress', status: msg.status }, '*')
      if (msg && msg.type === 'ig-pause') window.postMessage({ type: 'dailies:ig-pause', until: msg.until }, '*')
      if (msg && msg.type === 'ig-progress') window.postMessage({ type: 'dailies:ig-progress', url: msg.url, total: msg.total, added: msg.added, done: msg.done, blocked: msg.blocked }, '*')
      if (msg && msg.type === 'ig-import') window.postMessage({ type: 'dailies:ig-import-result', ...msg }, '*')
      if (msg && msg.type === 'iglist') window.postMessage({ type: 'dailies:iglist-result', nonce: msg.nonce, user: msg.user, cols: msg.cols, error: msg.error, until: msg.until }, '*')
      if (msg && msg.type === 'ytlist') window.postMessage({ type: 'dailies:ytlist-result', nonce: msg.nonce, list: msg.list, error: msg.error }, '*')
      if (msg && msg.type === 'pinuser') window.postMessage({ type: 'dailies:pinuser-result', nonce: msg.nonce, user: msg.user, boards: msg.boards, error: msg.error }, '*')
      if (msg && msg.type === 'ig-status') window.postMessage({ type: 'dailies:ig-status', status: msg.status }, '*')
      if (msg && msg.type === 'ig-follow') window.postMessage({ type: 'dailies:ig-follow', cols: msg.cols }, '*')
      if (msg && msg.type === 'enriched') window.postMessage({ type: 'dailies:enriched', result: msg.result }, '*')
      if (msg && msg.type === 'searched') window.postMessage({ type: 'dailies:searched', nonce: msg.nonce, scope: msg.scope, results: msg.results, next: msg.next }, '*')
      if (msg && msg.type === 'pickedimage') window.postMessage({ type: 'dailies:pickedimage', id: msg.id, img: msg.img }, '*')
      if (msg && msg.type === 'pin-preview') window.postMessage({ type: 'dailies:pin-preview', url: msg.url, pins: msg.pins || [] }, '*')
      if (msg && msg.type === 'have') window.postMessage({ type: 'dailies:have', nonce: msg.nonce, ids: msg.ids || [] }, '*')
      if (msg && msg.type === 'peeked') window.postMessage({ type: 'dailies:peeked', nonce: msg.nonce, url: msg.url, result: msg.result }, '*')
    })
    // the link drops when the extension is reloaded (this copy is finished) or its background goes to sleep (it reconnects
    // the next time Dailies asks for something, below)
    // the background went to sleep (MV3 does that after ~30 s idle): reopen the link straight away, so a save made in the
    // popup or on a post lands here at once instead of waiting for the next thing Dailies asks for
    port.onDisconnect.addListener(() => { if (alive()) { port = null; setTimeout(connect, 600) } else gone() })
    window.postMessage({ type: 'dailies:ext', v: chrome.runtime.getManifest().version }, '*') // so Dailies knows the extension is here
  }
  function onMessage(e) {
    if (e.source !== window || !e.data || !ASKS.has(e.data.type)) return
    if (!port) connect() // the link dropped while the extension's background slept: open it again
    if (!port) return
    try { forward(e) } catch { if (!alive()) gone() } // the extension went away mid-message
  }
  function forward(e) {
    if (e.data.type === 'dailies:result') port.postMessage(e.data)
    if (e.data.type === 'dailies:boards') port.postMessage({ type: 'boards', boards: e.data.boards || [], force: e.data.force === true })
    if (e.data.type === 'dailies:igcols') port.postMessage({ type: 'igcols', cols: e.data.cols || [], force: !!e.data.force })
    if (e.data.type === 'dailies:vocab') port.postMessage({ type: 'vocab', tags: e.data.tags || [] })
    if (e.data.type === 'dailies:stop') port.postMessage({ type: 'stop' })
    if (e.data.type === 'dailies:iglist') port.postMessage({ type: 'iglist', nonce: e.data.nonce })
    if (e.data.type === 'dailies:igimport') port.postMessage({ type: 'igimport', cols: e.data.cols || [] })
    if (e.data.type === 'dailies:ytlist') port.postMessage({ type: 'ytlist', link: String(e.data.link || ''), nonce: e.data.nonce })
    if (e.data.type === 'dailies:pinuser') port.postMessage({ type: 'pinuser', user: String(e.data.user || ''), nonce: e.data.nonce })
    if (e.data.type === 'dailies:enrich') port.postMessage({ type: 'enrich', items: e.data.items || [] })
    if (e.data.type === 'dailies:search') port.postMessage({ type: 'search', q: String(e.data.q || ''), scope: String(e.data.scope || ''), page: e.data.page, nonce: String(e.data.nonce || '') })
    if (e.data.type === 'dailies:pickimage') port.postMessage({ type: 'pickimage', id: String(e.data.id || '') })
    if (e.data.type === 'dailies:have-result') port.postMessage({ type: 'have-result', nonce: String(e.data.nonce || ''), have: Array.isArray(e.data.have) ? e.data.have.map(String) : [] })
    if (e.data.type === 'dailies:peek') port.postMessage({ type: 'peek', url: String(e.data.url || ''), nonce: String(e.data.nonce || '') })
  }
  window.addEventListener('message', onMessage)
  try { chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'reconnect' && !port) connect() }) } catch { /* no runtime */ }
  new MutationObserver(connect).observe(document.documentElement, { attributes: true, attributeFilter: ['data-dailies-inbox'] })
  connect()
})()
